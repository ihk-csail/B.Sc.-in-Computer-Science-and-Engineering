// In a bank, a customer a open any account, whether it can be savings or it can be fixed.

public class PolymorphicBehaviorOfObjects {
	public static void main(String[] args) {

		/*
		// Before Polymorphic Behavior of Objects	
		SavingsAccount sa1 = new SavingsAccount(1, "Mr. Abc", 500, 10.5);
		Customer c1 = new Customer("Mr. Abc", "01673412381", sa1, null);

		FixedAccount fa1 = new FixedAccount(2, "Mr. Def", 10000, 2);
		Customer c2 = new Customer("Mr. Def", "01643142281", null, fa1);

		System.out.println(c1.show());
		System.out.println(c2.show());*/

		Account sa2 = new SavingsAccount(3, "Mr. Ghi", 1500, 9.5);
		Customer c3 = new Customer("Mr. Ghi", "01673412381", sa2);

		System.out.println(c3.show());

		Account sa3 = new FixedAccount(4, "Mr. Mno", 150000, 3);
		Customer c4 = new Customer("Mr. Mno", "01973452381", sa3);

		System.out.println(c4.show());
	}
}

class Customer {

	private String customerName;
	private String phoneNumber;
	/*private SavingsAccount sa;
	private FixedAccount fa;*/
	private Account acc;

	public Customer() {

	}

	/*public Customer(String customerName, String phoneNumber, SavingsAccount sa, FixedAccount fa) {
		this.customerName = customerName;
		this.phoneNumber = phoneNumber;
		this.sa = sa;
		this.fa = fa;
	}*/

	public Customer(String customerName, String phoneNumber, Account acc) {
		this.customerName = customerName;
		this.phoneNumber = phoneNumber;
		this.acc = acc;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	/*public void setSavingsAccount(SavingsAccount sa) {
		this.sa = sa;
	}

	public SavingsAccount getSavingsAccount() {
		return sa;
	}

	public void setFixedAccount(FixedAccount fa) {
		this.fa = fa;
	}

	public FixedAccount getFixedAccount() {
		return fa;
	}*/

	public void setAccount(Account acc) {
		this.acc = acc;
	}

	public Account getAccount() {
		return acc;
	}

	/*public String show() {
		if(sa != null) {
			return "customerName: " + customerName + " phoneNumber: " + phoneNumber + " sa: " + sa.show();
		}
		else if(fa != null) {
			return "customerName: " + customerName + " phoneNumber: " + phoneNumber + " fa: " + fa.show();
		}
		else {
			return "customerName: " + customerName + " phoneNumber: " + phoneNumber;
		}
	}*/

	public String show() {
		return "customerName: " + customerName + " phoneNumber: " + phoneNumber + " acc: " + acc.show();
	}
}

class Account {
	private int accountNumber;
	private String accountHolderName;
	private double balance;

	public Account() {

	}

	public Account(int accountNumber, String accountHolderName, double balance) {
		this.accountNumber = accountNumber;
		this.accountHolderName = accountHolderName;
		this.balance = balance;
	}

	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	} 

	public int getAccountNumber() {
		return accountNumber;
	}

	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}

	public String getAccountHolderName() {
		return accountHolderName;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public double getBalance() {
		return balance;
	}

	public String show() {
		return "accountNumber: " + accountNumber + " accountHolderName: " + accountHolderName + " balance: " + balance;
	}
}

class SavingsAccount extends Account {
	private double interestRate;

	public SavingsAccount() {

	}

	public SavingsAccount(int accountNumber, String accountHolderName, double balance, double interestRate) {
		super(accountNumber, accountHolderName, balance);
		this.interestRate = interestRate;
	}

	public void setInterestRate(double interestRate) {
		this.interestRate = interestRate;
	}

	public double getInterestRate() {
		return interestRate;
	}

	public String show() {
		return super.show() + " interestRate: " + interestRate;
	}
}

class FixedAccount extends Account {
	private int tenureYear;

	public FixedAccount() {

	}

	public FixedAccount(int accountNumber, String accountHolderName, double balance, int tenureYear) {
		super(accountNumber, accountHolderName, balance);
		this.tenureYear = tenureYear;
	}

	public void setTenureYear(int tenureYear) {
		this.tenureYear = tenureYear;
	}

	public int getTenureYear() {
		return tenureYear;
	}

	public String show() {
		return super.show() + " tenureYear: " + tenureYear;
	}
}


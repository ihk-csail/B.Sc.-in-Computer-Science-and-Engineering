public class Abstraction {

	public static void main(String[] args) {

		// 2. An abstract class is a class that we can not instantiate 
		// error: ClassA is abstract; cannot be instantiated
		// ClassA cA = new ClassA();

		// 3. We can use Object Reference of an abstract class
		ClassA cA = new ClassC();
		cA.methodA2();

		ClassB cB = new ClassC();
		cB.methodA2();
		cB.methodB1();

		ClassC cC = new ClassC();
		cC.methodA2();
		cC.methodB1();
		cC.methodC1();
	}
}

//1. This is the declaration of abstraction class.
abstract class ClassA {

	// 4. Abstract class can have any type of attributes
	int a;
	static int b;

	// 4. Abstract class can have constructors (default or parameterized)
	ClassA() {
		System.out.println("Default Constructor of ClassA");
	}

	ClassA(int a) {
		// 4. We can create constructor chaining using this and super in abstract class
		this();
		System.out.println("Parameterized Constructor of ClassA");
	}

	//5. An abstract class may have regular methods/ Concrete Methods

	void methodA1() {
		System.out.println("1. ClassA - MethodA1");
	}

	// 5. An abstract class may have abstract methods
	/* error: abstract methods cannot have a body
	abstract void methodA2() {

	}*/

	abstract void methodA2();

	// 6. It is not mandatory to have an abstract mehtod inside an abstract class
	// but if you declare an abstract method then you must declare your class as abstract
}
/*
See the point number 6
error: ClassZ is not abstract and does not override abstract method methodA2() in ClassZ
class ClassZ {

	abstract void methodA2();
}*/

// 7.An abstract class MUST have a child class.
// 8. if we declare an empty classB, 
// 8. It will throw an error becuase there is no implementation of abstract methods 
abstract class ClassB extends ClassA {

	ClassB() {
		super(10);
		System.out.println("Default Constructor of ClassB");
	}

	// Solution 1 is declare classB as abstract, so you do not need to implement those abstract method.

	// Solution 2 for point number 8, so that I don't need to declare ClassB as abstract
	/*void methodA2() {

	}*/

	// 9. Suppose I go with solution 1
	// If the child class is another abstract class, that child class will have another child class which has to be a regular class

	abstract void methodB1();

}

// finally! a class which is a regular can, now I can create instance
class ClassC extends ClassB {

	// I can have other things like variables and constructos and other methods inside my regular class

	int x;
	static int z;

	ClassC() {
		System.out.println("Default Constructor of ClassC");
	}

	void methodA2() {
		System.out.println("2. ClassC - MethodA2()");
	}

	void methodB1() {
		System.out.println("3. ClassC - MethodB1()");
	}

	// It is ClassC's own method
	void methodC1() {
		System.out.println("4. ClassC - MethodC1()");
	}
}


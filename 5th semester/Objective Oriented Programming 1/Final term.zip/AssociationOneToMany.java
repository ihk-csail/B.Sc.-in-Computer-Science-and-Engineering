public class AssociationOneToMany {

	public static void main(String[] args) {

		Account acc1 = new Account();
		acc1.setAccountNumber(1011);
		acc1.setAccountHolderName("Abc");
		acc1.setBalance(500.0);
		//System.out.println(acc1.show());

		Account acc2 = new Account();
		acc2.setAccountNumber(1012);
		acc2.setAccountHolderName("Abc");
		acc2.setBalance(3500);
		//System.out.println(acc2.show());

		Account acc3 = new Account();
		acc3.setAccountNumber(1013);
		acc3.setAccountHolderName("Abc");
		acc3.setBalance(2200);
		//System.out.println(acc3.show());

		System.out.println();

		Customer c1 = new Customer();
		c1.setCustomerName("Abc");
		c1.setPhoneNumber("01982425511");
		// Here I am passing the reference of Account (Array of objects) to my customer class;
		
		Account acc[] = new Account[3];
		acc[0] = acc1;
		acc[1] = acc2;
		acc[2] = acc3;

		c1.setAccounts(acc);
		System.out.println(c1.show());
		//You will get an error from the below line. Why?
		//System.out.println(c1.getAccounts().show());
		System.out.println(c1.getAccounts()[0].show());
		System.out.println(c1.getAccounts()[1].show());
		System.out.println(c1.getAccounts()[2].show());
	}
}

class Account {

	private int accountNumber;
	private String accountHolderName;
	private double balance;

	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}

	public int getAccountNumber() {
		return accountNumber;
	}

	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}

	public String getAccountHolderName() {
		return accountHolderName;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public double getBalance() {
		return balance;
	}

	public String show() {
		return "accountNumber: " + accountNumber + " accountHolderName: " + accountHolderName + " balance: " + balance;
	}
}

class Customer {

	private String customerName;
	private String phoneNumber;
	// Customer Has Accounts
	private Account acc[];

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setAccounts(Account acc[]) {
		this.acc = acc;
	}

	public Account[] getAccounts() {
		return acc;
	}

	public String show() {
		/*return "customerName: " + customerName + " phoneNumber: " + phoneNumber + " acc: " + acc;*/

		/*return "customerName: " + customerName + " phoneNumber: " + phoneNumber + " accountNumber: " + acc.accountNumber + " accountHolderName: " + acc.accountHolderName + " balance: " + acc.balance;*/

		/*return "customerName: " + customerName + " phoneNumber: " + phoneNumber + " accountNumber: " + acc.getAccountNumber() + " accountHolderName: " + acc.getAccountHolderName() + " balance: " + acc.getBalance();*/

		/*return "customerName: " + customerName + " phoneNumber: " + phoneNumber + " " + acc.show();*/

		return "customerName: " + customerName + " phoneNumber: " + phoneNumber;
	}
}
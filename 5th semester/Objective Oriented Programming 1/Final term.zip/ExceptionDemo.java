import java.util.Scanner;
import java.util.InputMismatchException;
import java.io.IOException;

public class ExceptionDemo {

	public static void main(String[] args) {

		// Understanding the java exceptions

		/*
			java.lang.ArithmeticException: / by zero
        	at ExceptionDemo.main(ExceptionDemo.java:8) 
		*/

        /*
		int d = 0;
		int result = 10 / d;
		System.out.println("1. After getting error");
		*/
		/*	2. Compile-time
			ExceptionDemo.java:19: error: variable p1 might not have been initialized 
		*/
		/*	
		Person p1;
		p1.setId(10);
		System.out.println("2. After getting error");
		*/

		/*  3. Run-time
			java.lang.NullPointerException
        	at ExceptionDemo.main(ExceptionDemo.java:27)
		*/
        /*	
		Person p1 = null;
		p1.setId(10);
		System.out.println("3. After getting error");
		*/

		/*  4.
			java.lang.ArrayIndexOutOfBoundsException: 12
        	at ExceptionDemo.main(ExceptionDemo.java:39)
		*/
        /*	
		int a[] = new int[10];
		// Successful Execution
		// System.out.println(a[8]);
		System.out.println(a[12]);
		System.out.println("4. After getting error");
		*/

		/*
			java.lang.NumberFormatException: For input string: "ABC"
        	at java.lang.NumberFormatException.forInputString(Unknown Source)
        	at java.lang.Integer.parseInt(Unknown Source)
        	at java.lang.Integer.parseInt(Unknown Source)
        	at ExceptionDemo.main(ExceptionDemo.java:51)
		*/

        /*
		// Correct input
		//String number1 = "123";
		String number2 = "ABC";
		int i = Integer.parseInt(number2);
		System.out.println("5. After getting error");
		*/

		/*
			6. How to trace, where the error/exception has occurred.
			java.lang.ArithmeticException: / by zero
        	at ClassA.createError(ExceptionDemo.java:94)
       	 	at ClassA.callTheMethodCreateError(ExceptionDemo.java:99)
        	at ExceptionDemo.main(ExceptionDemo.java:65)
		*/
        /*	
		ClassA cA1 = new ClassA();
		cA1.callTheMethodCreateError();
		*/

		Scanner sc = new Scanner(System.in);
		int i = 0;
		// System.out.println("Please enter a number: ");

		/*
			java.util.InputMismatchException
        	at java.util.Scanner.throwFor(Unknown Source)
        	at java.util.Scanner.next(Unknown Source)
        	at java.util.Scanner.nextInt(Unknown Source)
        	at java.util.Scanner.nextInt(Unknown Source)
        	at ExceptionDemo.main(ExceptionDemo.java:82)
			
			i = sc.nextInt();

		*/
		/*
		ExceptionDemo.java:95: error: 'try' without 'catch', 'finally' or resource declarations	

		// What if I write only try block without any catch or finally
		try {
			i = sc.nextInt();
		}
		*/
		
		/*
		// 1. You have to write try and catch or try and finally together. You can not write other lines between these two blocks
        // 2. Catch block will only execute if exception has occured from immediate try block
        // 3. If you don't know the exact execption class then in catch block parameter just use the Exception class's object
        // 4, Suppose you don't want generic exepction class, you are going to provide the exact same exception which is supposed to be thrown from try block. Then you should be careful about
        //    the exact exception class. As if you provide the wrong exception class then it will be thrown to java catch-all or default exception handler
		try {
			i = sc.nextInt();
		}
		catch (ArithmeticException ex) {
			System.out.println("Exception occurred! Please enter a valid number.");
		}
		*/
		
		/*
		// Multiple catch block

		try {
			// First try will correct input - No exception
			// Now try with input 0 - ArithmeticException
			// Now try with input 'A' - InputMismatchException
			// If there is an exception inside try block, it will not execute rest of the line inside try block.
			i = sc.nextInt();
			System.out.println("Test whether this line will execute or not");
			int d = 10 / i;
		}
		catch (ArithmeticException ar) {
			System.out.println("ArithmeticException occurred! Please enter a valid number.");
		}
		catch (InputMismatchException ime) {
			System.out.println("InputMismatchException occurred! Please enter a valid number.");
		}
		catch (NullPointerException np) {
			System.out.println("NullPointerException occurred! Please enter a valid number.");
		}
		*/

		/*
    	// Rules to use Multiple catch block
        // 1. You need maintaing Hierarchy of exception classes, For example
        // Exception class has many childs, one of them is RuntimeException class, in RuntimeException class there are several classes, like ArithmeticException, NullPointerException
        // So first you need to write catch for child class then sequentially go to parent classes, otherwise you will get compile time error
        // You don't need to maintaing hierarchy for siblings
		try {
			// First try will correct input - No exception
			// Now try with input 0 - ArithmeticException
			// Now try with input 'A' - InputMismatchException
			// If there is an exception inside try block, it will not execute rest of the line inside try block.
			i = sc.nextInt();
			// System.out.println("Test whether this line will execute or not");
			int d = 10 / i;
		}
		// Uncomment the below code, you will get compile time error, why?
		// catch (Exception ex) {
		// 	System.out.println("Exception occurred! Please enter a valid number.");
		// }
		catch (ArithmeticException ar) {
			System.out.println("ArithmeticException occurred! Please enter a valid number.");
			// System.out.println(ar);
			// ar.printStackTrace();
			System.out.println(ar.getMessage());
		}
		catch (InputMismatchException ime) {
			System.out.println("InputMismatchException occurred! Please enter a valid number.");
		}
		catch (NullPointerException np) {
			System.out.println("NullPointerException occurred! Please enter a valid number.");
		}
		catch (RuntimeException rte) {
			System.out.println("RuntimeException occurred! Please enter a valid number.");
		}
		catch (Exception ex) {
			System.out.println("Exception occurred! Please enter a valid number.");
		}
		// catch (RuntimeException rte) {
		// 	System.out.println("RuntimeException occurred! Please enter a valid number.");
		// }

		System.out.println("i: " + i);
		System.out.println("7. After getting error");
		*/

		/*
		// finally block
		// try {
		// 	// int d1 = 10 / 10;
		// 	int d2 = 10 / 0;
		// }
		// finally {
		// 	System.out.println("This block will execute, whatever the situation is");
		// }

		try {
			// int d1 = 10 / 10;
			int d2 = 10 / 0;
		}
		catch (ArithmeticException ar) {
			System.out.println("ArithmeticException occurred! Please enter a valid number.");
		}
		catch (InputMismatchException ime) {
			System.out.println("InputMismatchException occurred! Please enter a valid number.");
		}
		catch (NullPointerException np) {
			System.out.println("NullPointerException occurred! Please enter a valid number.");
		}
		catch (Exception ex) {
			System.out.println("Exception occcurred!");
		}
		finally {
			System.out.println("This block will execute, whatever the situation is");
		}
		// You can not declare multple finally block
		// finally {
		// 	System.out.println("This block will execute, whatever the situation is");
		// }
		// ExceptionDemo.java:201: error: 'catch' without 'try'
		// catch (Exception ex) {
		// 	System.out.println("Exception occcurred!");
		// }

		System.out.println("8. After getting error");
		*/
		
		/*
		// Inner try catch finally 
		try {
			try {
				try {

				}
				catch(Exception ex) {

				}
			}
			catch(Exception ex) {

			}
		}
		catch(Exception ex) {
			try {

			}
			catch(Exception ex) {
				try {

				}
				catch(Exception ex) {

				}
			}
		}
		finally {
			try {

			}
			catch(Exception ex) {

			}
		}
		*/

		// throw vs throws

		// ClassA cA2 = new ClassA();
		// You need to use try catch here as exception has thrown from the method
		// cA2.createAnotherError();

		// try {
		// 	cA2.createAnotherError();
		// }
		// catch (IOException io) {
		// 	System.out.println("IOException occurred!");
		// }
		// catch (Exception ex) {
		// 	System.out.println("Exception occurred!");
		// }


		// User Defined Exception

		ClassB cB1 = new ClassB();
		// cB1.customException();

		try {
			cB1.customException();
		}
		catch (Exception ex) {
			System.out.println(ex.getMessage());
		}
	}
}

class Person {

	private int id;
	private String name;

	public void setId(int id) {
		this.id = id;
	}

	public int getId() {
		return id;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}
}

class ClassA {

	public void createError() {
		int a = 10 / 0;
		System.out.println("6. After getting error");
	}

	public void callTheMethodCreateError() {
		this.createError();
	}

	public void createAnotherError() throws IOException, ArithmeticException, InputMismatchException {
		// int a = 10 / 0;

		// ExceptionDemo.java:306: error: unreachable statement
		// throw new ArithmeticException();
		// throw new InputMismatchException();

		// ExceptionDemo.java:310: error: unreported exception IOException; must be caught or declared to be thrown
		// throw new IOException();

		/*try {
			throw new IOException();
		}
		catch (Exception ex) {
			System.out.println("Exception occurred");
		}*/

		// throw new IOException();
	}
}

class ClassB {
	public void customException() throws Exception {
		// ExceptionDemo.java:345: error: unreported exception UserDefinedException1; must be caught or declared to be thrown
		// throw new UserDefinedException1("UserDefinedException1 occurred!");

		// try {
		// 	throw new UserDefinedException1("UserDefinedException1 occurred!");
		// }
		// catch (Exception ex) {
		// 	System.out.println("Error");
		// }

		Scanner sc = new Scanner(System.in);
		System.out.println("Please enter a price: ");
		if(sc.nextInt() > 0) {
			System.out.println("Price Ok");
		}
		else {
			throw new PriceHighException("Please enter a price greater than 0");
		}
	}	
}

class UserDefinedException1 extends Exception {

	public UserDefinedException1(String s) {
		super(s);
	}

	public UserDefinedException1(String s, Throwable t) {
		t.printStackTrace();
	}
}

// also test this classes
class UserDefinedException2 extends RuntimeException {

	public UserDefinedException2(String s) {
		System.out.println(s);
	}
}

// also test this classes
class UserDefinedException3 extends IOException {

	public UserDefinedException3(String s) {
		System.out.println(s);
	}
}

class PriceHighException extends Exception {

	public PriceHighException(String s) {
		super(s);
		// System.out.println(s);
	}
}
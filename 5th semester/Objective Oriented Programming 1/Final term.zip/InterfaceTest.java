public class InterfaceTest {

	public static void main(String[] args) {

		// We can not create any objects of an interface, but we can take object reference.
		// error: IInterfaceDemo is abstract; cannot be instantiated
		// IInterfaceDemo iD = new IInterfaceDemo();

		// but we can take object reference
		// IInterfaceDemo iD;

		// Interface attributes are by default static test.
		System.out.println(IInterfaceDemo.x);

		// Interface attributes are by default final test.
		// error: cannot assign a value to final variable x
		// IInterfaceDemo.x = 10;

		// This is an static interface method, that's why I am able to call it in this way
		IInterfaceDemo.interfaceMethodA2();

		// error: non-static method interfaceMethodA1() cannot be referenced from a static context
		// IInterfaceDemo.interfaceMethodA1();
	}
}
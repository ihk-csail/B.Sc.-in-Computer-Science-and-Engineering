public class AssociationOneToOne {

	public static void main(String[] args) {

		Account acc1 = new Account();
		acc1.setAccountNumber(1011);
		acc1.setAccountHolderName("Abc");
		acc1.setBalance(500.0);

		System.out.println(acc1);
		System.out.println(acc1.show());

		Customer c1 = new Customer();
		c1.setCustomerName("Abc");
		c1.setPhoneNumber("01982425511");
		// Here I am passing the reference of Account to my customer class;
		c1.setAccount(acc1);

		System.out.println(c1.show());
		System.out.println(c1.getAccount().show());
	}
}

class Account {

	private int accountNumber;
	private String accountHolderName;
	private double balance;

	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}

	public int getAccountNumber() {
		return accountNumber;
	}

	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}

	public String getAccountHolderName() {
		return accountHolderName;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public double getBalance() {
		return balance;
	}

	public String show() {
		return "accountNumber: " + accountNumber + " accountHolderName: " + accountHolderName + " balance: " + balance;
	}
}

class Customer {

	private String customerName;
	private String phoneNumber;
	// Customer Has-A/An Account
	private Account acc;

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setAccount(Account acc) {
		this.acc = acc;
	}

	public Account getAccount() {
		return acc;
	}

	public String show() {
		//return "customerName: " + customerName + " phoneNumber: " + phoneNumber + " acc: " + acc;

		/*return "customerName: " + customerName + " phoneNumber: " + phoneNumber + " accountNumber: " + acc.accountNumber + " accountHolderName: " + acc.accountHolderName + " balance: " + acc.balance;*/

		/*return "customerName: " + customerName + " phoneNumber: " + phoneNumber + " accountNumber: " + acc.getAccountNumber() + " accountHolderName: " + acc.getAccountHolderName() + " balance: " + acc.getBalance();*/

		/*return "customerName: " + customerName + " phoneNumber: " + phoneNumber + " " + acc.show();*/

		return "customerName: " + customerName + " phoneNumber: " + phoneNumber;
	}
}
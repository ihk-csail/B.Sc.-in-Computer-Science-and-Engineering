// 1. Interface Declaration
//  error: modifier private not allowed here
// private interface IInterfaceDemo

//  error: modifier protected not allowed here
// protected interface IInterfaceDemo

// Interfaces are by default public whether you declare public keyword or not
public interface IInterfaceDemo {

	// 2. An interface may have attributes. But these attributes are by default public, static and final all at the same time
	// public static final int x;

	// I will get an error by the line
	//  error: = expected
	// int x;
	int x = 20;

	// 3. An interface does not have any constructors
	// error: <identifier> expected
	/*IInterfaceDemo() {
		System.out.println("Default Constructor of IInterfaceDemo");
	}*/

	// 4. All the methods of an interface are by default public and abstract.
	
	// error: interface abstract methods cannot have body
	/*void interfaceMethodA1() {

	}*/

	// public abstract void interfaceMethodA1();
	void interfaceMethodA1();

	// However, if we want to give body to any method of an interface, we have to declare the method as static.
	static void interfaceMethodA2() {
		System.out.println("I can declare method body if I declare the method as static");
	}

}
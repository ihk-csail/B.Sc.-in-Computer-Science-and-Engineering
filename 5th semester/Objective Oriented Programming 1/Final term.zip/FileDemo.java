import java.io.File;
import java.io.IOException;
import java.io.FileWriter;
import java.io.FileReader;
import java.io.BufferedReader;
import java.lang.NullPointerException;

public class FileDemo {

	public static void main(String[] args) {

		// Ways to create file

	    File f = new File("E:\\PDF\\data.txt");
		//File f = new File("data.txt");

		try {
		    System.out.println("1. File existst: " + f.exists());
			f.createNewFile();
		    System.out.println("2. File existst: " + f.exists());
			System.out.println("1. File getAbsolutePath: " + f.getAbsolutePath());
		    System.out.println("1. File canRead: " + f.canRead());

		}
		catch (IOException io) {
			System.out.println("IOException caught");
		}

		 System.out.println("File Created");


		// Ways to write inside a file

		 FileWriter fw = null;

		 try {
		 	fw = new FileWriter(f, true);

		 	String s = "This is a java course\n";
		 	fw.write(s);
		 	fw.write(s);
		 }
		 catch (IOException io) {
		 	System.out.println("IOException caught while writing inside a file");
		 }
		 finally {
		 	try {
		 		fw.close();
		 	}
		 	catch (IOException io) {
		 		System.out.println("IOException caught while closing file");
		 	}
		 }

		// Ways to read inside a file


		// Single character read
		 FileReader fr = null;

		 try {
	    	fr = new FileReader(f);
		 	int i = 0;

		 	while((i = fr.read()) != -1) {
		 		System.out.print((char)i);
		 	}
		 }
		 catch (IOException io) {
		 	System.out.println("IOException caught while reading a file");
		 }
		 finally {
		 	try {
		 		fr.close();
		 	}
		 	catch (IOException io) {
		 		System.out.println("IOException caught while closing file");
			}
		 }


		// Line read

		//FileReader fr = null;
		BufferedReader br = null;

		try {
			fr = new FileReader(f);
			br = new BufferedReader(fr);
			
			String line = "";

			while((line = br.readLine()) != null) {
				System.out.println(line);
			}
		}
		catch (IOException io) {
			System.out.println("IOException caught while reading a file");
		}
		finally {
			try {
				br.close();
			}
			catch (IOException io) {
				System.out.println("IOException caught while closing file");
			}
		}
		 boolean isDeleted = f.delete();
		 if(isDeleted) {
		 	System.out.println("File Deleted");
		 }
	}
}
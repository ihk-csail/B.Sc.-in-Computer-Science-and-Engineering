public class FinalDemo {
	public static void main(String[] args) {
		ClassA cA = new ClassA();
		System.out.println(cA.x);

		// I was trying to modify the final vairable
		// error: cannot assign a value to final variable x
		// cA.x = 20;

		System.out.println(ClassA.y);

		// final method is just like a regular methods, we can call them using object name
		cA.methodA1();
		cA.methodA1(10);
	}
}

// final class declaration
// apply the below line for ClassA declaration
// final class ClassA
class ClassA {

	// 1. Final Attributes

	// Declaration of final attribute
	//  error: variable x not initialized in the default constructor
	// final int x;

	// Declaration of final and also initialization together
	// final int x = 10;

	final int x;

	/*static final int y = 20;*/
	static final int y;

	static {
		y = 20;
	}

	// If I have 2 or 3 constructos I need to initialize my final variable in all the constructors
	// Otherwise I will get an error.
	//  error: variable x might not have been initialized

	ClassA() {
		x = 10;
		// error: cannot assign a value to final variable y
		// As it has been declared as static also
		// y = 20;
	}

	ClassA(int a) {
		x = 10;
		// error: cannot assign a value to final variable y
		// As it has been declared as static also
		// y = 20;
	}

	// Here we will also use method overloading concept, that like static, final method does not have any impact on method overloading

	// final method Declaration
	final void methodA1() {
		System.out.println("1. ClassA - MethodA1()");
	}

	void methodA1(int a) {
		System.out.println("2. ClassA - MethodA1(int a)");
	}
}

// We can not inherit final class
// error: cannot inherit from final ClassA
/*class ClassB extends ClassA {

}*/

class ClassC extends ClassA {

	ClassC() {
		// error: cannot assign a value to final variable x
		/*super.x = 30;*/
	}

	// Method Overriding is not possible if there is a final method
	// error: methodA1() in ClassC cannot override methodA1() in ClassA
	/*void methodA1() {
		System.out.println("3. ClassC - MethodA1()");
	}*/
}

// We can not use final and abstract keyword together, why?
// error: illegal combination of modifiers: abstract and final
// final abstract class ClassD {

// }


// We can not have abstract method inside a final Class, why?
// error: ClassE is not abstract and does not override abstract method methodE1() in ClassE
// I can not inherit ClassE, so how Can I override the mehtod methodE1?
/*final class ClassE {

	abstract void methodE1();
}*/
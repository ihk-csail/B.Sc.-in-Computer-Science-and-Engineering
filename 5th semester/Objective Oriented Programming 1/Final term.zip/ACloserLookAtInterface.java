public class ACloserLookAtInterface {
	public static void main(String[] args) {
		// IInterfaceA iA1 = new IInterfaceAI();

		IInterfaceA iA2 = new ClassA();
		iA2.interfaceMethodA1();
	}
}

// 1.  interface can not inherit a class
// error: class, interface, or enum expected
/*class ClassZ {
	private int a;

	public void setA(int a) {
		this.a = a;
	}

	public int getA() {
		return a;
	}
}

// inteface IInterfaceZ implements ClassZ {
// 
//}

//inteface IInterfaceZ extends ClassZ {
//
// }
*/

// 1. end--------------------

// 2. Inteface can extends other interfaces (Multiple)
interface IInterfaceA {
	void interfaceMethodA1();

	// Comment out the above line and implement the interface to a class, you will not get any error, why?
	/*static void interfaceMethodA2() {
		System.out.println("InterfaceA - interfaceMethodA2()");
	}*/
}

interface IInterfaceB extends IInterfaceA {
	void interfaceMethodB1();
}

interface IInterfaceC {
	void interfaceMethodC1();
}

interface IInterfaceD {
	void interfaceMethodD1();
}

interface IInterfaceE extends IInterfaceB, IInterfaceC, IInterfaceD {
	void interfaceMethodE1();
}
// 2. end --------------------

// We can implement multiple interfaces for abstract class too
// abstract class ClassZ implements IInterfaceA, IInterfaceC
abstract class ClassZ implements IInterfaceA {
	
	// error: interfaceMethodA1() in ClassZ cannot implement interfaceMethodA1() in IInterfaceA
    // abstract void interfaceMethodA1();
    // abstract void interfaceMethodA1();
	public abstract void interfaceMethodA1();
}

class ClassA implements IInterfaceB {

 	// Don't forget to give public access modifiers, as public is the top-level access modifier here
	public void interfaceMethodA1() {
		System.out.println("1. ClassA - interfaceMethodA1()");
	}

	public void interfaceMethodB1() {
		System.out.println("2. ClassA - interfaceMethodB1()");
	}
}

class ClassB implements IInterfaceC, IInterfaceD {
	public void interfaceMethodC1() {
		System.out.println("3. ClassB - interfaceMethodC1()");
	}

	public void interfaceMethodD1() {
		System.out.println("3. ClassB - interfaceMethodD1()");
	}
}

class ClassC extends ClassA implements IInterfaceC, IInterfaceD {
	public void interfaceMethodC1() {
		System.out.println("4. ClassC - interfaceMethodC1()");
	}

	public void interfaceMethodD1() {
		System.out.println("5. ClassC - interfaceMethodD1()");
	}
}
/*
In Java root class in java.lang.Object

There is a method called toString()

Returns a string representation of the object.
*/

// public class ToStringExample extends Object
public class ToStringExample {
	public static void main(String[] args) {

		Person p = new Person();

		p.setId(1);
		p.setName("Mr. Abc");

		// The following two lines will give same result
		System.out.println(p);
		// we are using method Method overriding concept
		System.out.println(p.toString());
	}
}

// class Person extends Object
class Person {

	private int id;
	private String name;

	public void setId(int id) {
		this.id = id;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	// I am overriding the method of Object class
	// Returns a string representation of the object.
	public String toString() {
		/*return "id: " + id + " name: " + name;*/
		return "id: " + getId() + " name: " + getName();
	}
}
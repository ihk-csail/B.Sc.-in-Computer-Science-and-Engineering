/*There MUST be inheritance between the two classes.
Method Name MUST be same.
Method Parameter MUST be same.
Method Return Type MUST be same.*/

// Method Overriding is also called run-time polymorphism or dynamic binding or late binding


public class MethodOverriding {

	public static void main(String[] args) {
		ClassB cB = new ClassB();
		cB.methodB();
		cB.methodA();
	}
}

class ClassA {

	void methodA() {
		System.out.println("1. ClassA - MethodA");
	}

	void methodA(int a) {
		System.out.println("2. ClassA - MethodA");
	}
}

class ClassB extends ClassA {

	void methodB() {
		System.out.println("1. ClassB - MethodB");
	}

	void methodA() {
		System.out.println("2. ClassB - MethodA");
	}

	/* 
	error: methodA() in ClassB cannot override methodA() in ClassA

	int methodA() {
		System.out.println("2. ClassB - MethodA");
		return 0;
	}
	*/


}

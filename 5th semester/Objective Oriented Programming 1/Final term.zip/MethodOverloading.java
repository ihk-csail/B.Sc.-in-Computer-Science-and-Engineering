// Methods MUST be in same class.
// Method Name MUST be same.
// Method Parameter MUST be different.
// Method Return Type may or may not be same.

// Method Overloading is also called compile-time polymorphism or static binding or early binding

public class MethodOverloading {
	public static void main(String[] args) {
		ClassA cA = new ClassA();
		cA.methodA(10);
		cA.methodA(10, 20);
		cA.methodA(10.00, 20);
	}	
}

class ClassA {
	// Here methodA is called overloaded methods
	
	void methodA() {
		System.out.println("Inside MethodA");
	}

	void methodA(int a) {
		System.out.println("Inside MethodA with int a: " + a);
	}

	void methodA(int a, int b) {
		System.out.println("Inside MethodA with int a:" + a + " and int b: " + b);
	}

	void methodA(int a, int b, int c) {
		System.out.println("Inside MethodA with int a:" + a + " and int b: " + b + " and int c: " + c);
	}

	void methodA(int a, double b) {
		System.out.println("Inside MethodA with int a:" + a + " and double b: " + b);
	}

	void methodA(double a, int b) {
		System.out.println("Inside MethodA with double a:" + a + " and int b: " + b);
	}

	void methodB() {
		System.out.println("Inside MethodB");
	}
}
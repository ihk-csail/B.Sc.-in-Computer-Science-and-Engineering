public class InheritanceBasicExample {

	public static void main(String[] args) {

		Teacher t = new Teacher();
		t.name = "ABC";
		t.age = 20;
		t.roomNo = "6A03";

		System.out.println("Name: " + t.name);
		System.out.println("Age: " + t.age);
		System.out.println("RoomNo: " + t.roomNo);

		System.out.println();

		Student s = new Student();
		s.name = "ABC";
		s.age = 20;
		s.cgpa = 3.5f;

		System.out.println("Name: " + s.name);
		System.out.println("Age: " + s.age);
		System.out.println("RoomNo: " + s.cgpa);

	}
}

class Person {
	String name;
	int age;
}

// Remove extends then check what you get.
class Teacher extends Person{
	// We are going to create another class called Person and will move name and age there
	// String name;
	// int age;
	String roomNo;
}

class Student extends Person {

	// Benefit is I don;t need to write name and age again

	float cgpa;
}
class DataType {
	public static void main(String[] args) {
		boolean b = true;
		char c = 'A';
		byte by = 125;
		short s = 130;
		int i = 200;
		long l = 250l;
		float f = 4.50f;
		double d = 8.90d; 

		System.out.println(b);
		System.out.println(c);
		System.out.println(by);
		System.out.println(s);
		System.out.println(i);
		System.out.println(l);
		System.out.println(f);
		System.out.println(d);


		// DataType Range Testing

		/* 
			Syntax for commenting multi line.
		*/

		/*
		s = 32768 
		// Min Value: -32768 Max Value: 32767
		DataType.java:28: error: ';' expected
                s = 32768 // Min Value: -32768 Max Value: 32767
                         ^
		1 error */

		s = 32767;
		System.out.println(s);

		/* Similarly you should check for other primitive Data Types */

	}
}
public class ObjectReference {

	public static void main(String[] args) {

		Account a1 = new Account(1111, 200.0);
		System.out.println("***Object is: a1***");
		a1.show();
		System.out.println(a1);

		System.out.println("-----------------");

		Account a2 = new Account(1112, 250.0);
		System.out.println("***Object is: a2***");
		a2.show();
		System.out.println(a2);

		System.out.println("-----------------");
		
		Account a3 = new Account(1113, 350.0);
		System.out.println("***Object is: a3***");
		a3.show();
		System.out.println(a3);

		System.out.println("-----------------");

		// No new memory will be created for a4;
		Account a4 = a2; // if a2 has memory location 06c34B then a4 will point the same memory location.
		System.out.println("***Object is: a4***");
		a4.show();
		System.out.println(a4);

		a4.balance = 550.0;

		System.out.println("---After balance of a4 is changed.---");

		System.out.println("***Object is: a4***");
		a4.show();
		System.out.println(a4);

		System.out.println("-----------------");
		
		System.out.println("***Object is: a2***");
		a2.show();
		System.out.println(a2);
	}

}

class Account{

	// Instance variables
	int accountNo;
	double balance;

	// Class variable or static variable
	static double perDayTransactionLimit= 500; // 06xB49
	
	// Default constructor
	Account( ){ }

	// Parameterized constructor
	Account(int an, double b){
		accountNo = an;	balance = b;
	}

	// Methods
	void addInterest(double rate){
		balance  = balance + (balance * rate / 100);
	}

	void show( ){
		System.out.println("AccountNo: " + accountNo);
		System.out.println("Balance: " + balance);
	}
}

class StaticInitializationBlock {	

	// Static variable or block executes before any object is created and before the constructor.

	static double perDayTransactionLimit;

	StaticInitializationBlock() {
		System.out.println("Calling default constructor...");
	}

 	// Static initialization block is called at first
	static {
		System.out.println("Static Initialization Block - 1");
		perDayTransactionLimit = 500;
	}

	static {
		System.out.println("Static Initialization Block - 2");
	}

	public static void main(String[] args) {
		System.out.println("Hello World");
		// Comment out the below line to check when the constructor is called.
		//StaticInitializationBlock sIB = new StaticInitializationBlock();

	}

	static {
		System.out.println("Static Initialization Block - 3");
	}
}
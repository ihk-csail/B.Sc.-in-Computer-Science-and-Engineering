// You should provide public access modifier to the class, who's name match with the source file
public class AllClassesInOneSourceFile {
	public static void main(String[] args) {
		FirstSourceFile fs = new FirstSourceFile();
		SecondSourceFile ss = new SecondSourceFile();
		ThridSourceFile ts = new ThridSourceFile();

		fs.setX(10);
		ss.setY(20);
		ts.setZ(30);

		System.out.println(fs.getX());
		System.out.println(ss.getY());
		System.out.println(ts.getZ());
	}
}

class FirstSourceFile {

	int x;

	void setX(int x1) {
		x = x1;
	}

	int getX() {
		return x;
	}
}

class SecondSourceFile {
	int y;

	void setY(int y1) {
		y = y1;
	}

	int getY() {
		return y;
	}
}

class ThridSourceFile {
	int z;

	void setZ(int z1) {
		z = z1;
	}

	int getZ() {
		return z;
	}
}
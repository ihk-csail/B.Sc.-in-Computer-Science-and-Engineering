class TheThisKeyword {

	int a;
	int b;

	TheThisKeyword() {
		System.out.println("Calling Default Constructor");
	}

	// remove the this keyword, then check the output. again remove the this keyword and change the parameter name.
	TheThisKeyword(int a, int b) {
		System.out.println("Calling Parameterized Constructor");
		this.a = a;
		this.b = b;
	}

	void setA(int a) {
		this.a = a; 
	}

	int getA() {
		return a;
	}

	void setB(int b) {
		this.b = b;
	}

	int getB() {
		return b;
	}

	public static void main(String[] args) {
		// Assigning value through Parameterized Constructor
		TheThisKeyword ttk1 = new TheThisKeyword(10, 20);
		System.out.println(ttk1.getA());
		System.out.println(ttk1.getB());

		// Default Constructor
		TheThisKeyword ttk2 = new TheThisKeyword();
		ttk2.setA(30);
		ttk2.setB(40);
		System.out.println(ttk2.getA());
		System.out.println(ttk2.getB());
	}
}
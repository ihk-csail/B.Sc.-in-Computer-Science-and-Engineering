// Person <-- Teacher

public class SingleInheritance {

	public static void main(String[] args) {

		Teacher t = new Teacher();
		t.setName("ABC");
		t.setAge(20);
		t.setRoomNo("6A03");

		System.out.println("Name: " + t.getName());
		System.out.println("Age: " + t.getAge());
		System.out.println("RoomNo: " + t.getRoomNo());

	}
}

// With Encapsulation
// Base Class
class Person {
	private String name;
	private int age;

	public void setName(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public int getAge() {
		return age;
	}
}

// Child Class
// Remove extends then check what you get.
class Teacher extends Person{
	// We are going to create another class called Person and will move name and age there
	// String name;
	// int age;
	private String roomNo;

	public void setRoomNo(String roomNo) {
		this.roomNo = roomNo;
	}

	public String getRoomNo() {
		return roomNo;
	}
}
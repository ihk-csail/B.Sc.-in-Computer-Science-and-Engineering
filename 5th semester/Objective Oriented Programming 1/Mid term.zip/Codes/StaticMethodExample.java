public class StaticMethodExample {

	public static void main(String[] args) {
		Test.methodA();

		Test t = new Test();
		t.methodC();
	}
}

class Test {

	// 1. Static method can hold static method calling and static variables only
	// 2. Non static method or Instance method can hold both static and non static methods and variables.

	// static variable or class variable
	static int i = 20;

	// instance variable or non static variable
	int j = 30;

	// static method or class method or static context
	static void methodA() {
		// Static Context
		System.out.println("Static Context MethodA");
		// It can be reference as it is also a static method
		// methodB();

		//error: non-static method methodC() cannot be referenced from a static context
		// methodC();
	}

	static void methodB() {
		// Static Context
		System.out.println("Static Context MethodB");
	}

	// Instance method or non static method

	void methodC() {
		// Non static context or instance context
		System.out.println("Instance MethodC");
		methodB();
		System.out.println(i);
		System.out.println(j);
	}
}
public class InheritanceConstructorExample {

	public static void main(String[] args) {

		Teacher t = new Teacher();
		t.name = "ABC";
		t.age = 20;
		t.roomNo = "6A03";

		System.out.println("Name: " + t.name);
		System.out.println("Age: " + t.age);
		System.out.println("RoomNo: " + t.roomNo);

		Lecturer l = new Lecturer();
	}
}

class Person {
	String name;
	int age;

	Person() {
		// Constructor Chaining
		this(10);
		System.out.println("Default Constructor of Person");
	}

	Person(int a) {
		System.out.println("Parameterized Constructor of Person");
	}
}

// Remove extends then check what you get.
class Teacher extends Person {
	// We are going to create another class called Person and will move name and age there
	// String name;
	// int age;
	String roomNo;

	Teacher() {
		// It is the default call and the first execution of any child class constructor
		super(); // Person();
		System.out.println("Default Constructor of Teacher");

		//error: call to super must be first statement in constructor
		// super(); // It will generate an error
	}
}

class Lecturer extends Teacher {

	Lecturer() {
		// We can not use super and this in a single constructor
		// super();
		// this(20);
		System.out.println("Default Constructor of Lecturer");
	}

	Lecturer(int b) {
		System.out.println("Parameterized Constructor of Lecturer");
	}

	//this.a = a;
	//super.a = a;
}
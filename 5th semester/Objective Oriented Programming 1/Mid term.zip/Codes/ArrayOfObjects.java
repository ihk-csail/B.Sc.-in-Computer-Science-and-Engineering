public class ArrayOfObjects {

	public static void main(String[] args) {
		// Try to take student information using User Input

		Student s[] = new Student[3];

		Student s1 = new Student();
		s1.id = 1;
		s1.name = "ABC";

		Student s2 = new Student();
		s2.id = 2;
		s2.name = "DEF";

		Student s3 = new Student();
		s3.id = 3;
		s3.name = "GHI";

		s[0] = s1;
		s[1] = s2;
		s[2] = s3;


		for(int i = 0; i < s.length; i++) {
			if(s[i] != null) {
				System.out.println(s[i].id + " " + s[i].name);
			}
		}

		System.out.println();

		s[1] = null;

		// Remove the if condition, you will get null pointer exception
		for(int i = 0; i < s.length; i++) {
			if(s[i] != null) {
				System.out.println(s[i].id + " " + s[i].name);
			}
		}
	}
}


class Student {

	int id;
	String name;
}
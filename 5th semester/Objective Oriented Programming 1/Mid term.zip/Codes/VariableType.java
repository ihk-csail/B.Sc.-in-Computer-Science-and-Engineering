public class VariableType {

	public static void main(String[] args) {
		System.out.println(Account.perDayTransactionLimit);

		/* error: non-static variable accountNo cannot be referenced from a static context
		System.out.println(Account.accountNo);
		*/

		// All the object of Account class will point to the same class variable
		Account.perDayTransactionLimit = 1000.0;

		Account a1 = new Account(1111, 200.0);
		System.out.println("***Object is: a1***");
		a1.show();
		System.out.println(a1);
		// Can we call class variable with object name? yes, but it is not recommended.
		System.out.println("perDayTransactionLimit: " + Account.perDayTransactionLimit);

		System.out.println("-----------------");

		Account a2 = new Account(1112, 250.0);
		System.out.println("***Object is: a2***");
		a2.show();
		System.out.println(a2);
		System.out.println("perDayTransactionLimit: " + Account.perDayTransactionLimit);

		System.out.println("-----------------");
		
		Account a3 = new Account(1113, 350.0);
		System.out.println("***Object is: a3***");
		a3.show();
		System.out.println(a3);
		System.out.println("perDayTransactionLimit: " + Account.perDayTransactionLimit);
	}

}

class Account{

	// Instance variables
	int accountNo;
	double balance;

	// Class variable or static variable
	static double perDayTransactionLimit= 500; // 06xB49
	
	// Default constructor
	Account( ){ }

	// Parameterized constructor
	Account(int an, double b){
		accountNo = an;	balance = b;
	}

	// Methods
	void addInterest(double rate){
		balance  = balance + (balance * rate / 100);
	}

	void show( ){
		System.out.println("AccountNo: " + accountNo);
		System.out.println("Balance: " + balance);
	}
}

// Class Declaration
// 'class' keyword and the name of the class then start with {} (curly-braces)
public class ClassAndObjectDemo {

	// Variables 
	int x;
	int y;
	int z;

	//Constructor
	// Default Constructor
	ClassAndObjectDemo() {
		System.out.println("Calling Default Constructor");
	}

	// Parameterized Constructor - 1
	ClassAndObjectDemo(int x1, int y1, int z1) {
		System.out.println("Calling Parameterized Constructor - 1");
		x = x1;
		y = y1;
		z = z1;
	}

	// Parameterized Constructor - 2
	ClassAndObjectDemo(int x1) {
		System.out.println("Calling Parameterized Constructor - 2");
		x = x1;
	}

	// Methods
	// return-type nameOfTheMethod () [first Brakcet] with parameter or without paramenter then start with {} (curly-braces)
	void setX(int x1) {
		x = x1;
	}

	int getX() {
		return x;
	}

	void setY(int y1) {
		y = y1;
	}

	int getY() {
		return y;
	}

	void setZ(int z1) {
		z = z1;
	}

	int getZ() {
		return z;
	}
}
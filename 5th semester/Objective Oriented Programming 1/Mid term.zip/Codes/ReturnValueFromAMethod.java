class ReturnValueFromAMethod {

	int v1;
	int v2;

	ReturnValueFromAMethod(int p1, int p2) {
		v1 = p1;
		v2 = p2;
	}

	// Return value from a method
	int result() {
		int res = v1 + v2;
		return res; 
	}


	public static void main(String[] args) {
		Addition a1 = new Addition(10, 20);
		System.out.println(a1.result());
	}

}
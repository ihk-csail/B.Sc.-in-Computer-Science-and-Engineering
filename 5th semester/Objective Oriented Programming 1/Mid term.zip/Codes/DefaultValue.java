public class DefaultValue {

	boolean b;
	int a;
	char c;
	float f;


	public static void main(String[] args) {
		DefaultValue dv = new DefaultValue();

		System.out.println(dv.b);
		System.out.println(dv.a);
		System.out.println(dv.c);
		System.out.println(dv.f);						
	}

}
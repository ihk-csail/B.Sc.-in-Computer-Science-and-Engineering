public class CommandLineArgument {

	public static void main(String[] args) {

		System.out.println("Command Line Argument: ");
		System.out.println("The length of Args is: " + args.length);

		// System.out.println(args[0]);
		// System.out.println(args[1]);
		// System.out.println(args[2]);
		// System.out.println(args[3]);

		for(int i = 0; i < args.length; i++) {
			System.out.println(args[i]);
		}
	}
}
// Person <-- Teacher <-- Lecturer

public class MultilevelInheritance {

	public static void main(String[] args) {

		Teacher t = new Teacher();
		t.setName("ABC");
		t.setAge(20);
		t.setRoomNo("6A03");

		System.out.println("Name: " + t.getName());
		System.out.println("Age: " + t.getAge());
		System.out.println("RoomNo: " + t.getRoomNo());

		System.out.println();

		Lecturer l = new Lecturer();
		l.setName("DEF");
		l.setAge(25);
		l.setRoomNo("7A");
		l.setCrHr(10.5f);

		System.out.println("Name: " + l.getName());
		System.out.println("Age: " + l.getAge());
		System.out.println("RoomNo: " + l.getRoomNo());
		System.out.println("CrHR: " + l.getCrHr());

	}
}

// With Encapsulation
class Person {
	private String name;
	private int age;

	public void setName(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public int getAge() {
		return age;
	}
}

// Remove extends then check what you get.
class Teacher extends Person {
	// We are going to create another class called Person and will move name and age there
	// String name;
	// int age;
	private String roomNo;

	public void setRoomNo(String roomNo) {
		this.roomNo = roomNo;
	}

	public String getRoomNo() {
		return roomNo;
	}
}

// It can access Person class properties though it is not extending Person class
class Lecturer extends Teacher {

	// Benefit is I don;t need to write name and age again

	private float crHr;

	public void setCrHr(float crHr) {
		this.crHr = crHr;
	}

	public float getCrHr() {
		return crHr;
	}
}
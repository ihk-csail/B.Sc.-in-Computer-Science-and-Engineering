class ArrayExample {

	public static void main(String[] args) {

		// 1st Approch

		System.out.println("1st Approch: ");

		int arr1[] = new int[5];

		// Initially all the values will be set to default values
		for(int i = 0; i < 5; i++) {
			System.out.println(arr1[i]);
		}

		System.out.println();

		// How to assign values to a specific position of array.
		arr1[1] = 20;
		arr1[4] = 40;

		// java.lang.ArrayIndexOutOfBoundsException
		// arr1[5] = 50;

		// To Check the values are assigned or not
		for(int i = 0; i < 5; i++) {
			System.out.println(arr1[i]);
		}


		// 2nd Approch

		System.out.println();
		System.out.println("2nd Approch: ");

		int arr2[];
		int size = 4/2;
		arr2 = new int[size];

		// length is the property of array to calculate the length of array
		for(int i = 0; i < arr2.length; i++) {
			System.out.println(arr2[i]);
		}

		arr2[0] = 100;

		System.out.println();

		for(int i = 0; i < arr2.length; i++) {
			System.out.println(arr2[i]);
		}


		// 3rd Approch

		System.out.println();
		System.out.println("3rd Approch: ");

		int arr3[] = new int[]{10, 20, 30, 40, 50, 60, 70, 80};

		System.out.println("Length of Array: " + arr3.length);

		for(int i = 0; i < arr3.length; i++) {
			System.out.println(arr3[i]);
		}


		// 2-D Array
		System.out.println();
		System.out.println("3rd Approch for 2D array: ");

		int arr4[][] = new int[][]{{10, 20}, {30, 40}, {50, 60} , {70, 80}};

		System.out.println("Length of Array: " + arr4.length);

		for(int i = 0; i < arr4.length; i++) {
			for(int j = 0; j < 2; j++) {
				System.out.println(arr4[i][j]);
			} 
		}
	}
}
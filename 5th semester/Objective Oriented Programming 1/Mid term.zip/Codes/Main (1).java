class Main {
	public static void main(String[] args) {

		//1.DataType (ClassName) 2.variableName 3.= 4.new keyword 5.Default Constructor of the Class
		ClassAndObjectDemo c1 = new ClassAndObjectDemo();
		c1.setX(20);
		System.out.println(c1.getX());
		System.out.println(c1);

		ClassAndObjectDemo c2 = new ClassAndObjectDemo();
		c2.setX(22);
		System.out.println(c2.getX());
		System.out.println(c2);

		ClassAndObjectDemo c3 = new ClassAndObjectDemo();
		c3.setX(42);
		System.out.println(c3.getX());
		System.out.println(c3);

		ClassAndObjectDemo c4 = new ClassAndObjectDemo(100);
		System.out.println(c4.getX());
		System.out.println(c4);	

		/* It will produce an error. an there is no constructor which is expecting 2 parameter 
		ClassAndObjectDemo c4 = new ClassAndObjectDemo(100, 200);
		System.out.println(c4.getX());
		System.out.println(c4);	
		*/

		ClassAndObjectDemo c5 = new ClassAndObjectDemo(100, 200, 300);
		System.out.println(c5.getX());
		System.out.println(c5.getY());
		System.out.println(c5.getZ());
		System.out.println(c5);	
	}
}
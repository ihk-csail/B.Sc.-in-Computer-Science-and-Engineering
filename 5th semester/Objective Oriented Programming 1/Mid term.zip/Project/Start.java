import java.lang.*;
import java.util.*;
import classes.*;
import interfaces.*;
import fileio.*;

public class Start
{
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		Market m = new Market();
		FileReadWriteDemo frwd = new FileReadWriteDemo();
		
		System.out.println(" Welcome to our Market Management Application ");
		
		boolean repeat = true;
		while(repeat)
		{
			System.out.println("What do you want to do?\n");
			System.out.println("---1. Employee Management");
			System.out.println("---2. Shop Management");
			System.out.println("---3. Exit\n");

			System.out.print("Your Choice: ");
		  
		    try
		{	   
			int choice = sc.nextInt();
			
			switch(choice)
		    {
				case 1:
				
					System.out.println("");
					System.out.println("You have choosen Employee Management");
					
					System.out.println("Choose any one Option from the followings :\n");
					System.out.println(" 1. Insert New Employee.  2.Get an Employee   3.Remove an Existing Employee  4. Show All Employees  5. Go Back\n");
					System.out.println();
					
					System.out.print("Your Option: ");
					int option1 = sc.nextInt();
					
					switch(option1)
					{
						case 1:
						
							System.out.println("########################");
							System.out.println("Insert New Employee");
							
							System.out.print("Enter Employee ID: ");
							String empId1 = sc.next();
							System.out.print("Enter Employee Name: ");
							String name1 = sc.next();
							System.out.println("Set Duration for your Employee: ");
							String time1= sc.next();
							System.out.print("Enter Employee Salary: ");
							double salary1 = sc.nextDouble();
							
							Internship e1 = new Internship();
							e1.setEmpId(empId1);
							e1.setName(name1);
							e1.setSalary(salary1);
							e1.setTime(time1);
							
							m.insertEmployee(e1);
							{

								frwd.writeInFile("Employee Added: "+ e1.getName()+" Duration: "+ e1.getTime()+" months"+"  Salary :"+e1.getSalary()+"  Id :"+e1.getEmpId());
							}
							
							System.out.println("########################");
							break;
							
						case 2:
						
							System.out.println("########################");
							System.out.println("Get An Employee");
							
							System.out.print("Enter Employee ID: ");
							String empId2 = sc.next();
							
							Internship e2 = m.getEmployee(empId2);
							
							if(e2 !=null)
							{
								System.out.println();
								System.out.println("Employee ID: "+e2.getEmpId());
								System.out.println("Employee Name: "+e2.getName());
								System.out.println("Employee worked here for: "+e2.getTime()+" months");
								System.out.println("Employee Salary: "+e2.getSalary());
								System.out.println();
							}
							else { System.out.println("Employee Not Found");}
							{

								frwd.writeInFile("Employee you got: "+ e2.getName()+"He is working here for : "+e2.getTime()+" months"+"  Salary :"+e2.getSalary()+"  Id :"+e2.getEmpId());
							}
							
							System.out.println("########################");
							break;
							
						case 3:
						
							System.out.println("########################");
							System.out.println("Remove an Existing Employee");
							
							System.out.print("Enter Employee ID: ");
							String empId3 = sc.next();
							
							Internship e3 = m.getEmployee(empId3);
							
							if(e3 != null)
							{
								m.removeEmployee(e3);
							}
							{

								frwd.writeInFile("Employee you removed: "+ e3.getName()+" He worked here for: "+e3.getTime()+"  Salary :"+e3.getSalary()+"  Id :"+e3.getEmpId());
							}
							System.out.println("########################");
							break;
							
						case 4:
						
							System.out.println("########################");
							System.out.println("Show All Employees");
							m.showAllEmployees();
							System.out.println("########################");
							break;
							
						case 5:
						
							System.out.println("########################");
							System.out.println("Going Back......");
							System.out.println("########################");
							break;
							
						default:
						
							System.out.println("########################");
							System.out.println("Invalid Option");
							System.out.println("########################");
							break;
					}
					
					System.out.println("");
					break;
					
				case 2:
				
					System.out.println("");
					System.out.println("You have choosen Shop Management");
					
					System.out.println("Choose any one Option from the followings:\n");
					System.out.println(" 1. Insert New Shop   2.Remove Existing Shop   3.Show All Shops   4.Search a Shop   5.Go Back\n ");
					
					
					System.out.print("Your Option: ");
					int option2 = sc.nextInt();
					
					switch(option2)
					{
						case 1:
						
							System.out.println("########################");
							System.out.println("Insert New Shop");
							
							System.out.print("Enter Shop ID: ");
							String sid1 = sc.next();
							System.out.print("Enter Shop Name: ");
							String name1 = sc.next();
							
							
							Shop s1 = new Shop();
							s1.setSid(sid1);
							s1.setName(name1);
						
							m.insertShop(s1);
							{

								frwd.writeInFile("shop you inserted: "+ s1.getName()+" He worked here for: "+"  Id :"+s1.getSid());
							}

							
							System.out.println("########################");
							break;
								
						case 2:
						
							System.out.println("########################");
							System.out.println("Remove an Existing Shop");
							
							System.out.print("Enter Shop ID: ");
							String sid2 = sc.next();
							
							Shop s2 = m.getShop(sid2);
							
							if(s2 != null)
							{
								m.removeShop(s2);
							}
							{

								frwd.writeInFile("shop you removed: "+ s2.getName()+" He worked here for: "+"  Id :"+s2.getSid());
							}

							
							System.out.println("########################");
							break;
							
						case 3:
						
							System.out.println("########################");
							System.out.println("Show All Shops");
							m.showAllShops( );
							System.out.println("########################");
							break;
							
						case 4:
						
							System.out.println("########################");
							System.out.println("Search a shop ");
							
							System.out.print("Enter Shop ID: ");
							String sid3 = sc.next();
							
							Shop s3 = m.getShop(sid3);
							
							if(s3 !=null)
							{
								System.out.println();
								System.out.println("Shop ID: "+s3.getSid());
								System.out.println("Shop Name: "+s3.getName());	
								System.out.println();
							}
							
							System.out.println("########################");
							break;
							
						case 5:
						
							System.out.println("########################");
							System.out.println("Going Back......");
							System.out.println("########################");
							break;
							
						default:
						
							System.out.println("########################");
							System.out.println("Invalid Option");
							System.out.println("########################");
							break;
					}
					
					System.out.println("");
					break;
				
								
				case 3:
				
					System.out.println("********************");
					System.out.println("Exit");
					repeat = false;
					System.out.println("********************");
					break;
					
				default:
				
					System.out.println("********************");
					System.out.println("Invalid Option");
					System.out.println("********************");
					
					
			}
			
		} 
            catch(InputMismatchException ime)
			{
				System.out.println("InputMismatchException occured");
				System.out.println("Please Enter Correct Input");
				String a = sc.next();
			}
			catch(NullPointerException npe)
			{
				System.out.println("NullPointerException occured");		
                System.out.println("Your input information does not exist");
				
			}
			catch(Exception e)
			{
				System.out.println("Exception occured ");
				e.printStackTrace();
				String a = sc.next();
				
			}
			
		}	
	}
	
}
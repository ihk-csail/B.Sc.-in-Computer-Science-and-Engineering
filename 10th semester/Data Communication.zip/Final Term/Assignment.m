clc;
clear all;
close all;
Transmitted_Message = 'mm88';
dec = double(Transmitted_Message); % text to ASCII (decimal)
p2 = 2.^(0:-1:-7); % 2^0,2^-1,.......,2^-7
B = mod(floor(p2'*dec),2); % decimal to binary conversion
% columns of B are bits of characters
x = reshape(B,1,numel(B));
disp('Transmitted message is:')
disp(Transmitted_Message)
disp('Binary information at Transmitter:');
disp(x);
disp(x);
F=8;
G=9;
br=(G+1)*10;
bp = 1/br;% bit period
%% representation of transmitting binary information as digital % signal
bit = [];
a0 = G+1; % amplitude for binary bit 00
a1 = G+5; % amplitude for binary bit 01
a2= 2*(G+5); % amplitude for binary bit 10
a3= F3*(G+5);% amplitude for binary bit 11
nt = 1000; % number of samples in a single bit period
for n =1:2:length(x)
if x(n) == 0 && x(n+1)== 0 ;
se = a0*ones(1,nt);
elseif x(n) == 0 && x(n+1)== 1;
se = a1*ones(1,nt);
elseif x(n) == 1 && x(n+1)== 0;
se = a2*ones(1,nt);
elseif x(n) == 1 && x(n+1)== 1;
se = a3*ones(1,nt);
end
bit = [bit se];
end
t = 0:2*(bp/nt):(length(x)*bp-bp/nt);
figure
plot(t,bit,'lineWidth',2.5);
ylabel('Amplitude(volt)');
xlabel('Time(sec)');
title('Transmitting information as digital signal');
f =(G+1)*40;
t1 =0:bp/nt:bp-bp/nt;
ss = length(t1);
m = [];
for (i = 1:2:length(x))
if (x(i) == 0 && x(i+1)== 0 )
y = a0*cos(2*pi*f*t1);
elseif (x(i) == 0 && x(i+1)== 1 )
y = a1*cos(2*pi*f*t1);
elseif (x(i) == 1 && x(i+1)== 0 )

    
y = a2*cos(2*pi*f*t1);
else (x(i) == 1 && x(i+1)== 1 )
y = a3*cos(2*pi*f*t1);
end
m = [m y];
end
t = 0:2*(bp/nt):(length(x)*bp-bp/nt);
figure
plot(t,m);
xlabel('Time(sec)');
ylabel('Amplitude(volt)');
title('Modulated Signal at Transmitter');
disp(' Message transmitted through a Transmission medium');
SNR = F+G+5;
t = 0:2*(bp/nt):(length(x)*bp-bp/nt);
Rec=awgn(m,SNR);
figure
plot(t,Rec,'linewidth',2);
xlabel('time(sec)');
ylabel('amplitude(volt)');
title('Received signal at Receiver');
nq = length(x)/2;
mn = [];
for q = 1:nq
t_in = 0:bp/nt:bp-bp/nt;
y = cos(2*pi*f*t_in); % carrier signal
mm = y.*Rec(((q-1)*nt+1):q*nt);
z = trapz(t_in,mm) ; % integration
zz = round((2*z/bp));
if(zz > ((a0+a1)/2) && zz < ((a1+a2)/2)) % logic level = (a1+a2)/2
a = 0;
a5 = 1;
elseif(zz >((a1+a2)/2) && zz < ((a2+a3)/2))
a = 1;
a5 =0;
elseif(zz >((a2+a3)/2))
a = 1;
a5 =1;
else
a = 0;
a5 = 0;
end
mn = [mn a a5];
end
disp(' Binary information at Reciver :');
disp(mn);
bit = [];
nt = 1000; % number of samples in a single bit period
for n =1:2:length(mn)
if x(n) == 0 && x(n+1)== 0 ;
se = a0*ones(1,nt);
elseif x(n) == 0 && x(n+1)== 1;
se = a1*ones(1,nt);
elseif x(n) == 1 && x(n+1)== 0;
se = a2*ones(1,nt);



elseif x(n) == 1 && x(n+1)== 1;
se = a3*ones(1,nt);
end
bit = [bit se];
end
t = 0:2*(bp/nt):(length(x)*bp-bp/nt);
figure
plot(t,bit,'lineWidth',2.5);
ylabel('Amplitude(volt)');
xlabel('Time(sec)');
title('Transmitting information as digital signal');
L = length(mn); % Length of input string
L8 = 8*floor(L/8); % Multiple of 8 Length
B = reshape(mn(1:L8),8,L8/8); % Columns of B are character bits
p2 = 2.^(0:7); %power of 2
dec = p2*B; %Binary to decimal conversion
txt2 = char(dec);
disp('Received Message is:')
disp(txt2);



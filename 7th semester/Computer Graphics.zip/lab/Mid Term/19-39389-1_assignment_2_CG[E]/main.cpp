#include <windows.h>
#include <GL/glut.h>
#include<math.h>>
# define PI           3.14159265358979323846

GLfloat j = 0.0f;
GLfloat k = 0.0f;
GLfloat l = 0.0f;


void Idle()
{
    glutPostRedisplay();
}

void display() {
    glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
	glClear(GL_COLOR_BUFFER_BIT);
	int i;


    glBegin(GL_QUADS);
	glColor3ub(255, 255, 255);
	glVertex2f(0.66,0.66);
	glVertex2f(-0.66, 0.66);
	glVertex2f(-0.66,-0.66);
	glVertex2f(0.66, -0.66);
	glEnd();

	glLineWidth(7);
	glBegin(GL_LINES);
	glColor3ub(0, 0, 0);
	glVertex2f(0.66,0.0);
	glVertex2f(0.60, 0.0);
	glEnd();

    glLineWidth(7);
	glBegin(GL_LINES);
	glColor3ub(0, 0, 0);
	glVertex2f(0.0,0.66);
	glVertex2f(0.0, 0.60);
	glEnd();

	glLineWidth(7);
	glBegin(GL_LINES);
	glColor3ub(0, 0, 0);
	glVertex2f(-0.66,0.0);
	glVertex2f(-0.60, 0.0);
	glEnd();

	glLineWidth(7);
	glBegin(GL_LINES);
	glColor3ub(0, 0, 0);
	glVertex2f(0.0,-0.66);
	glVertex2f(0.0, -0.60);
	glEnd();


    //creating watch stick
    glPushMatrix(); //second
    glRotatef(j,0.0,0.0,0.1);
    glLineWidth(2);
	glBegin(GL_LINES);
	glColor3ub(241, 196, 15);
	glVertex2f(0.0,0.0);
	glVertex2f(0.0, 0.6);
	glEnd();
	glPopMatrix();
	 j-=0.003f;

	 glLoadIdentity();

	glPushMatrix(); //minute
    glRotatef(k,0.0,0.0,0.1);
	glLineWidth(2.5);
	glBegin(GL_LINES);
	glColor3ub(186, 37, 0);
	glVertex2f(0.0,0.0);
	glVertex2f(0.45, 0.0);
	glEnd();
	glPopMatrix();
	k -=0.0003f;

	glPushMatrix(); //hour
    glRotatef(l,0.0,0.0,0.1);
	glLineWidth(4);
	glBegin(GL_LINES);
	glColor3ub(43, 0, 186);
	glVertex2f(0.0,0.0);
	glVertex2f(-0.35, 0);
	glEnd();
    glPopMatrix();
	 l-=0.0001f;


	glFlush();


}

int main(int argc, char** argv)
{
	glutInit(&argc, argv);
	glutCreateWindow("analog clock");
	glutInitWindowSize(320, 320);
	glutDisplayFunc(display);
	glutIdleFunc(Idle);
	glutMainLoop();
	return 0;
}

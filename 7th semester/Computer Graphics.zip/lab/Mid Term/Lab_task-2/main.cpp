
#include<windows.h>
#include <windows.h>  // for MS Windows
#include <GL/glut.h>  // GLUT, include glu.h and gl.h
#include<math.h>>
# define PI           3.14159265358979323846
/* Handler for window-repaint event. Call back when the window first appears and
whenever the window needs to be re-painted. */
void display() {
	glClearColor(0.0f, 0.0f, 0.0f, 1.0f); // Set background color to black and opaque
	glClear(GL_COLOR_BUFFER_BIT);     // Clear the color buffer (background)

    glBegin(GL_LINES);              // Each set of 4 vertices form a quad
	glColor3f(1.0f, 0.0f, 0.0f); // Red
	glVertex2f(-1.0f, 0.0f);
	glVertex2f(1.0f, 0.0f);
	glEnd();
	glBegin(GL_LINES);  //drawing coordinate
	glColor3f(1.0f, 0.0f, 0.0f);
	glVertex2f(0.0f, 1.0f);
	glVertex2f(0.0f, -1.0f);
	glEnd();

	glBegin(GL_TRIANGLES); //drawing triangle using triangle
	glColor3ub(153, 153, 102);
	glVertex2f(0.6f, 0.9f);
	glVertex2f(0.4f, 0.6f);
	glVertex2f(0.8f, 0.6f);
	glEnd();
	glBegin(GL_TRIANGLES); //drawing triangle using triangle
	glColor3ub(153, 153, 102);
	glVertex2f(0.0f, 0.9f);
	glVertex2f(-0.2f, 0.6f);
	glVertex2f(0.3f, 0.6f);
	glEnd();
	glBegin(GL_TRIANGLES); //drawing triangle using triangle
	glColor3ub(153, 153, 102);
	glVertex2f(-0.4f, 1.0f);
	glVertex2f(-0.9f, 0.6f);
	glVertex2f(0.0f, 0.6f);
	glEnd();

	glBegin(GL_QUADS); //drawing rectangle using quads
	glColor3f(0.0f, 0.0f, 1.0f);
	glVertex2f(0.1f, -0.4f);
	glVertex2f(0.2f, -0.5f);
	glVertex2f(0.6f, -0.5f);
	glVertex2f(0.7f, -0.4f);
	glEnd();
	glBegin(GL_QUADS); //drawing rectangle using quads
	glColor3f(0.0f, 0.0f, 1.0f);
	glVertex2f(0.3f, -0.3f);
	glVertex2f(0.2f, -0.4f);
	glVertex2f(0.6f, -0.4f);
	glVertex2f(0.5f, -0.3f);
	glEnd();



	GLfloat x=.3f; GLfloat y=.2f; GLfloat radius =.2f;
	int i;
	int lineAmount = 150;
	GLfloat twicePi = 2.0f * PI;

	glBegin(GL_LINE_LOOP);
	glColor3ub(255, 0, 102);
		for(i = 0; i <= lineAmount;i++) {
			glVertex2f(
			    x + (radius * cos(i *  twicePi / lineAmount)),
			    y + (radius* sin(i * twicePi / lineAmount))
			);
		}
	glEnd();

	x=0.9f; y=0.9f;  radius =.07f;
	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(255, 204, 0);
		for(i = 0; i <= lineAmount;i++) {
			glVertex2f(
			    x + (radius * cos(i *  twicePi / lineAmount)),
			    y + (radius* sin(i * twicePi / lineAmount))
			);
		}
	glEnd();

	x=0.4f; y=-0.32f;  radius =.02f;
	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(255, 0, 102);
		for(i = 0; i <= lineAmount;i++) {
			glVertex2f(
			    x + (radius * cos(i *  twicePi / lineAmount)),
			    y + (radius* sin(i * twicePi / lineAmount))
			);
		}
	glEnd();


	x=-.5f; y=.2f;  radius =.2f;

	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(255, 0, 102);
		for(i = 0; i <= lineAmount;i++) {
			glVertex2f(
			    x + (radius * cos(i *  twicePi / lineAmount)),
			    y + (radius* sin(i * twicePi / lineAmount))
			);
		}
	glEnd();

	glFlush();
}

int main(int argc, char** argv) {
	glutInit(&argc, argv);                 // Initialize GLUT
	glutCreateWindow("OpenGL Setup Test"); // Create a window with the given title
	glutInitWindowSize(320, 320);   // Set the window's initial width & height
	glutDisplayFunc(display); // Register display callback handler for window re-paint
	glutMainLoop();           // Enter the event-processing loop
	return 0;
}

#include <windows.h>
#include <GL/glut.h>
#include <math.h>
# define PI           3.14159265358979323846

void display() {
	glClearColor(1.0f, 1.0f, 1.0f, 1.0f);
	glClear(GL_COLOR_BUFFER_BIT);

    glBegin(GL_QUADS);              //1
	glColor3ub(0, 0, 77);
	glVertex2f(-0.3f, 1.0f);
    glVertex2f(-0.3f, 0.8f);
	glVertex2f(-0.1f, 0.8f);
    glVertex2f(-0.1f, 1.0f);
	glEnd();
	glBegin(GL_QUADS);              //11
	glColor3ub(0, 0, 90);
	glVertex2f(0.3f, 1.0f);
    glVertex2f(0.3f, 0.8f);
	glVertex2f(0.1f, 0.8f);
    glVertex2f(0.1f, 1.0f);
	glEnd();
	glBegin(GL_QUADS);              //111
	glColor3ub(0, 0, 90);
	glVertex2f(-0.3f, 0.8f);
    glVertex2f(-0.3f, 0.6f);
	glVertex2f(0.3f, 0.6f);
    glVertex2f(0.3f, 0.8f);
	glEnd();
	glBegin(GL_QUADS);              //shade
	glColor3ub(0, 0, 50);
	glVertex2f(-0.3f, 1.0f);
    glVertex2f(-0.3f, 0.6f);
	glVertex2f(-0.1f, 0.6f);
    glVertex2f(-0.1f, 1.0f);
	glEnd();

	glBegin(GL_QUADS);              //2
	glColor3ub(230, 138, 0);
	glVertex2f(-0.3f, 0.6f);
    glVertex2f(-0.3f, 0.4f);
	glVertex2f(0.3f, 0.4f);
    glVertex2f(0.3f, 0.6f);
	glEnd();
	glBegin(GL_QUADS);              //shade
	glColor3ub(153, 77, 0);
	glVertex2f(-0.3f, 0.6f);
    glVertex2f(-0.3f, 0.4f);
	glVertex2f(-0.1f, 0.4f);
    glVertex2f(-0.1f, 0.6f);
	glEnd();

	glBegin(GL_QUADS);              //3
	glColor3ub(184, 184, 148);
	glVertex2f(-0.45f, 0.45f);
    glVertex2f(-0.45f, 0.0f);
	glVertex2f(0.45f, 0.0f);
    glVertex2f(0.45f, 0.45f);
	glEnd();

	glBegin(GL_QUADS);              //4
	glColor3ub(61, 61, 41);
	glVertex2f(-0.225f, 0.33f);
    glVertex2f(-0.225f, 0.18f);
	glVertex2f(0.225f, 0.18f);
    glVertex2f(0.225f, 0.33f);
	glEnd();

	glBegin(GL_QUADS);              //7
	glColor3ub(255, 204, 0);
	glVertex2f(-0.45f, 0.08f);
    glVertex2f(-0.45f, -0.1f);
	glVertex2f(0.45f, -0.1f);
    glVertex2f(0.45f, 0.08f);
	glEnd();

	glBegin(GL_QUADS);              //10
	glColor3ub(89, 89, 89);
	glVertex2f(-0.15f, -0.1f);
    glVertex2f(-0.15f, -0.8f);
	glVertex2f(-0.45f, -0.8f);
    glVertex2f(-0.45f, -0.1f);
	glEnd();
	glBegin(GL_QUADS);              //10
	glColor3ub(64, 64, 64);
	glVertex2f(-0.30f, -0.1f);
    glVertex2f(-0.30f, -0.8f);
	glVertex2f(-0.45f, -0.8f);
    glVertex2f(-0.45f, -0.1f);
	glEnd();
	glBegin(GL_QUADS);              //1010
	glColor3ub(89, 89, 89);
	glVertex2f(0.15f, -0.1f);
    glVertex2f(0.15f, -0.8f);
	glVertex2f(0.45f, -0.8f);
    glVertex2f(0.45f, -0.1f);
	glEnd();
	glBegin(GL_QUADS);              //1010
	glColor3ub(64, 64, 64);
	glVertex2f(0.15f, -0.1f);
    glVertex2f(0.15f, -0.8f);
	glVertex2f(0.30f, -0.8f);
    glVertex2f(0.30f, -0.1f);
	glEnd();

	glBegin(GL_QUADS);              //9
	glColor3ub(0, 0, 102);
	glVertex2f(-0.30f, -0.1f);
    glVertex2f(-0.30f, -0.5f);
	glVertex2f(0.30f, -0.5f);
    glVertex2f(0.30f, -0.1f);
	glEnd();
	glBegin(GL_QUADS);              //99
	glColor3ub(0, 0, 77);
	glVertex2f(-0.45f, -0.1f);
    glVertex2f(-0.45f, -0.3f);
	glVertex2f(-0.30f, -0.3f);
    glVertex2f(-0.30f, -0.1f);
	glEnd();
	glBegin(GL_QUADS);              //999
	glColor3ub(0, 0, 102);
	glVertex2f(0.45f, -0.1f);
    glVertex2f(0.45f, -0.3f);
	glVertex2f(0.30f, -0.3f);
    glVertex2f(0.30f, -0.1f);
	glEnd();

	glBegin(GL_QUADS);              //8
	glColor3ub(13, 13, 13);
	glVertex2f(-0.15f, -0.5f);
    glVertex2f(-0.15f, -0.66f);
	glVertex2f(0.15f, -0.66f);
    glVertex2f(0.15f, -0.5f);
	glEnd();

	glBegin(GL_QUADS);              //9999
	glColor3ub(0, 0, 77);
	glVertex2f(-0.15f, -0.8f);
    glVertex2f(-0.15f, -0.99f);
	glVertex2f(-0.45f, -0.99f);
    glVertex2f(-0.45f, -0.8f);
	glEnd();
	glBegin(GL_QUADS);              //9999
	glColor3ub(0, 0, 50);
	glVertex2f(-0.30f, -0.8f);
    glVertex2f(-0.30f, -0.99f);
	glVertex2f(-0.45f, -0.99f);
    glVertex2f(-0.45f, -0.8f);
	glEnd();
	glBegin(GL_QUADS);              //99999
	glColor3ub(0, 0, 77);
	glVertex2f(0.15f, -0.8f);
    glVertex2f(0.15f, -0.99f);
	glVertex2f(0.45f, -0.99f);
    glVertex2f(0.45f, -0.8f);
	glEnd();
	glBegin(GL_QUADS);              //99999
	glColor3ub(0, 0, 50);
	glVertex2f(0.15f, -0.8f);
    glVertex2f(0.15f, -0.99f);
	glVertex2f(0.30f, -0.99f);
    glVertex2f(0.30f, -0.8f);
	glEnd();

	glBegin(GL_QUADS);              //333
	glColor3ub(184, 184, 148);
	glVertex2f(-0.65f, 0.33f);
    glVertex2f(-0.65f, 0.18f);
	glVertex2f(-0.45f, 0.18f);
    glVertex2f(-0.45f, 0.33f);
	glEnd();
	glBegin(GL_QUADS);              //5
	glColor3ub(230, 92, 0);
	glVertex2f(-0.65f, 0.18f);
    glVertex2f(-0.65f, 0.08f);
	glVertex2f(-0.45f, 0.08f);
    glVertex2f(-0.45f, 0.18f);
	glEnd();
	glBegin(GL_QUADS);              //6
	glColor3ub(0, 0, 128);
	glVertex2f(-0.65f, 0.08f);
    glVertex2f(-0.65f, -0.1f);
	glVertex2f(-0.45f, -0.1f);
    glVertex2f(-0.45f, 0.08f);
	glEnd();
	glBegin(GL_QUADS);              //88
	glColor3ub(13, 13, 13);
	glVertex2f(-0.65f, -0.1f);
    glVertex2f(-0.65f, -0.7f);
	glVertex2f(-0.45f, -0.7f);
    glVertex2f(-0.45f, -0.1f);
	glEnd();

	glBegin(GL_QUADS);              //333
	glColor3ub(184, 184, 148);
	glVertex2f(0.65f, 0.33f);
    glVertex2f(0.65f, 0.18f);
	glVertex2f(0.45f, 0.18f);
    glVertex2f(0.45f, 0.33f);
	glEnd();
	glBegin(GL_QUADS);              //5
	glColor3ub(230, 92, 0);
	glVertex2f(0.65f, 0.18f);
    glVertex2f(0.65f, 0.08f);
	glVertex2f(0.45f, 0.08f);
    glVertex2f(0.45f, 0.18f);
	glEnd();
	glBegin(GL_QUADS);              //6
	glColor3ub(0, 0, 128);
	glVertex2f(0.65f, 0.08f);
    glVertex2f(0.65f, -0.1f);
	glVertex2f(0.45f, -0.1f);
    glVertex2f(0.45f, 0.08f);
	glEnd();
	glBegin(GL_QUADS);              //88
	glColor3ub(13, 13, 13);
	glVertex2f(0.65f, -0.1f);
    glVertex2f(0.65f, -0.7f);
	glVertex2f(0.45f, -0.7f);
    glVertex2f(0.45f, -0.1f);
	glEnd();




	glFlush();
}



int main(int argc, char** argv) {
	glutInit(&argc, argv);
	glutCreateWindow("OpenGL Setup");
	glutInitWindowSize(320, 320);
	glutDisplayFunc(display);
	glutMainLoop();
	return 0;
}


#include<windows.h>
#include <windows.h>  // for MS Windows
#include <GL/glut.h>  // GLUT, include glu.h and gl.h
#include<math.h>>
# define PI           3.14159265358979323846
/* Handler for window-repaint event. Call back when the window first appears and
whenever the window needs to be re-painted. */
void display() {

	glClearColor(0.0f, 0.7f, 1.0f, 2.0f); // Set background color to black and opaque
	glClear(GL_COLOR_BUFFER_BIT);     // Clear the color buffer (background)

    glBegin(GL_QUADS); //drawing lower rectangle using quads
	glColor3ub(51, 204, 255);
	glVertex2f(-1.0f, 0.2f);
	glVertex2f(-1.0f, -1.0f);
	glVertex2f(1.0f, -1.0f);
	glVertex2f(1.0f, 0.2f);
	glEnd();

	glBegin(GL_QUADS); //drawing the port's platform
	glColor3ub(128, 128, 128);
	glVertex2f(-0.3f, 0.17f);
	glVertex2f(-0.25f, 0.05f);
	glVertex2f(1.0f, 0.05f);
	glVertex2f(1.0f, 0.17f);
	glEnd();

    glBegin(GL_QUADS); //drawing the tower platform
	glColor3ub(26, 26, 26);
	glVertex2f(-0.2f, 0.2f);
	glVertex2f(-0.2f, 0.17f);
	glVertex2f(-0.1f, 0.17f);
	glVertex2f(-0.1f, 0.2f);
	glEnd();
	glBegin(GL_QUADS); //drawing the tower
	glColor3ub(77, 77, 77);
	glVertex2f(-0.18f, 0.4f);
	glVertex2f(-0.18f, 0.2f);
	glVertex2f(-0.12f, 0.2f);
	glVertex2f(-0.12f, 0.4f);
	glEnd();

	glBegin(GL_QUADS); //drawing 1st career platform
	glColor3ub(77, 77, 77);
	glVertex2f(0.6f, 0.2f);
	glVertex2f(0.6f, 0.17f);
	glVertex2f(0.4f, 0.17f);
	glVertex2f(0.4f, 0.2f);
	glEnd();
	glBegin(GL_QUADS); //drawing the career
	glColor3ub(77, 77, 77);
	glVertex2f(0.48f, 0.5f);
	glVertex2f(0.48f, 0.2f);
	glVertex2f(0.52f, 0.2f);
	glVertex2f(0.52f, 0.5f);
	glEnd();
	glBegin(GL_QUADS); //drawing 2nd career platform
	glColor3ub(77, 77, 77);
	glVertex2f(0.3f, 0.2f);
	glVertex2f(0.3f, 0.17f);
	glVertex2f(0.5f, 0.17f);
	glVertex2f(0.5f, 0.2f);
	glEnd();
	glBegin(GL_QUADS); //drawing the career
	glColor3ub(77, 77, 77);
	glVertex2f(0.38f, 0.5f);
	glVertex2f(0.38f, 0.2f);
	glVertex2f(0.42f, 0.2f);
	glVertex2f(0.42f, 0.5f);
	glEnd();
	glBegin(GL_QUADS); //drawing the 1st career horizontal
	glColor3ub(77, 77, 77);
	glVertex2f(0.38f, 0.48f);
	glVertex2f(0.38f, 0.46f);
	glVertex2f(0.1f, 0.46f);
	glVertex2f(0.1f, 0.48f);
	glEnd();
	glBegin(GL_QUADS); //drawing the 2nd career horizontal
	glColor3ub(77, 77, 77);
	glVertex2f(0.38f, 0.48f);
	glVertex2f(0.38f, 0.46f);
	glVertex2f(0.8f, 0.46f);
	glVertex2f(0.8f, 0.48f);
	glEnd();
	glBegin(GL_LINES); //drawing 1st ropes of career
	glColor3ub(77, 77, 77);
	glVertex2f(0.1f, 0.48f);
	glVertex2f(0.1f, 0.25f);
	glEnd();
	glBegin(GL_LINES); //drawing 2nd ropes of career
	glColor3ub(77, 77, 77);
	glVertex2f(0.8f, 0.48f);
	glVertex2f(0.8f, 0.32f);
	glEnd();


    //drawing the 1st ships
	glBegin(GL_QUADS); //drawing the 1st ship
	glColor3ub(77, 77, 77);
	glVertex2f(-0.25f, -0.1f);
	glVertex2f(-0.22f, -0.16f);
	glVertex2f(0.32f, -0.16f);
	glVertex2f(0.33f, -0.1f);
	glEnd();
	glBegin(GL_QUADS); //drawing the 1st ship
	glColor3ub(77, 77, 77);
	glVertex2f(0.32f, -0.15f);
	glVertex2f(0.18f, -0.15f);
	glVertex2f(0.18f, -0.04f);
	glVertex2f(0.32f, -0.04f);
	glEnd();
	glBegin(GL_QUADS); //drawing border of the 1st ship
	glColor3ub(255, 255, 204);
	glVertex2f(-0.25f, -0.09f);
	glVertex2f(-0.25f, -0.1f);
	glVertex2f(0.33f, -0.1f);
	glVertex2f(0.33f, -0.09f);
	glBegin(GL_QUADS); //drawing shadow of the 1st ship
	glColor3ub(176, 176, 130);
	glVertex2f(-0.25f, -0.18f);
	glVertex2f(-0.22f, -0.16f);
	glVertex2f(0.32f, -0.16f);
	glVertex2f(0.33f, -0.18f);
	glEnd();

	//drawing container
	glBegin(GL_QUADS); //drawing blue container
	glColor3ub(0, 0, 179);
	glVertex2f(0.02f, 0.25f);
	glVertex2f(0.02f, 0.14f);
	glVertex2f(0.17f, 0.14f);
	glVertex2f(0.17f, 0.25f);
	glEnd();
	glBegin(GL_QUADS); //drawing yellow container
	glColor3ub(2255, 173, 51);
	glVertex2f(-0.22f, -0.01f);
	glVertex2f(-0.22f, -0.09f);
	glVertex2f(-0.09f, -0.09f);
	glVertex2f(-0.09f, -0.01f);
	glEnd();
	glBegin(GL_QUADS); //drawing red container
	glColor3ub(255, 51, 51);
	glVertex2f(-0.07f, -0.09f);
	glVertex2f(-0.07f, -0.01f);
	glVertex2f(0.01f, -0.01f);
	glVertex2f(0.01f, -0.09f);
	glEnd();

	//drawing the 2nd ships
	glBegin(GL_QUADS); //drawing the ship
	glColor3ub(77, 77, 77);
	glVertex2f(-0.8f, -0.5f);
	glVertex2f(-0.8f, -0.64f);
	glVertex2f(0.05f, -0.64f);
	glVertex2f(0.1f, -0.5f);
	glEnd();
	//glBegin(GL_QUADS); //drawing the ship
	glColor3ub(77, 77, 77);
	glVertex2f(0.32f, -0.15f);
	glVertex2f(0.18f, -0.15f);
	glVertex2f(0.18f, -0.04f);
	glVertex2f(0.32f, -0.04f);
	glEnd();
	/*glBegin(GL_QUADS); //drawing border of the 1st ship
	glColor3ub(255, 255, 204);
	glVertex2f(-0.25f, -0.09f);
	glVertex2f(-0.25f, -0.1f);
	glVertex2f(0.33f, -0.1f);
	glVertex2f(0.33f, -0.09f);
	glBegin(GL_QUADS); //drawing shadow of the 1st ship
	glColor3ub(176, 176, 130);
	glVertex2f(-0.25f, -0.18f);
	glVertex2f(-0.22f, -0.16f);
	glVertex2f(0.32f, -0.16f);
	glVertex2f(0.33f, -0.18f);
	glEnd();*/





	GLfloat x=.3f; GLfloat y=.2f; GLfloat radius =.2f;
	int i;
	int lineAmount = 150;
	GLfloat twicePi = 2.0f * PI;

	x=-0.8f; y=0.8f;  radius =.07f; //drawing the sun
	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(255, 204, 0);
		for(i = 0; i <= lineAmount;i++) {
			glVertex2f(
			    x + (radius * cos(i *  twicePi / lineAmount)),
			    y + (radius* sin(i * twicePi / lineAmount))
			);
		}
	glEnd();

	x=-0.15f; y=0.42f;  radius =.07f; //drawing the tower
	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(77, 77, 77);
		for(i = 0; i <= lineAmount;i++) {
			glVertex2f(
			    x + (radius * cos(i *  twicePi / lineAmount)),
			    y + (radius* sin(i * twicePi / lineAmount))
			);
		}
	glEnd();


	glFlush();
}

int main(int argc, char** argv) {
	glutInit(&argc, argv);                 // Initialize GLUT
	glutCreateWindow("OpenGL Setup Test"); // Create a window with the given title
	glutInitWindowSize(320, 320);   // Set the window's initial width & height
	glutDisplayFunc(display); // Register display callback handler for window re-paint
	glutMainLoop();           // Enter the event-processing loop
	return 0;
}


#include <windows.h>  // for MS Windows
#include<cstdio>
#include <GL/gl.h>
#include <GL/glut.h>
#include<math.h>>
# define PI           3.14159265358979323846
/* Handler for window-repaint event. Call back when the window first appears and
whenever the window needs to be re-painted. */

GLfloat position = 0.0f;
GLfloat speed = 0.006f;

void update(int value) {

    if(position >1.1)
        position = -1.0f;

    position += speed;

	glutPostRedisplay();


	glutTimerFunc(100, update, 0);
}

GLfloat position1 = 0.0f;
GLfloat speed1 = 0.003f;
void update1(int value) {

    if(position1 <-1.0)
        position1 = 1.0f;

    position1 -= speed1;

	glutPostRedisplay();


	glutTimerFunc(100, update1, 0);
}

void display() {

	glClearColor(0.0f, 0.7f, 1.0f, 2.0f); // Set background color to black and opaque
	glClear(GL_COLOR_BUFFER_BIT);     // Clear the color buffer (background)



    glBegin(GL_QUADS); //drawing lower rectangle using quads
	glColor3ub(51, 204, 255);
	glVertex2f(-1.0f, 0.2f);
	glVertex2f(-1.0f, -1.0f);
	glVertex2f(1.0f, -1.0f);
	glVertex2f(1.0f, 0.2f);
	glEnd();

	glBegin(GL_LINES);// drawing wave
	glColor3ub(255, 255, 255);
	glVertex2f(0.8f, -0.8f);
	glVertex2f(0.6f, -0.8f);
	glEnd();
	glBegin(GL_LINES);// drawing wave
	glColor3ub(255, 255, 255);
	glVertex2f(0.4f, -0.9f);
	glVertex2f(0.1f, -0.9f);
	glEnd();
	glBegin(GL_LINES);// drawing wave
	glColor3ub(255, 255, 255);
	glVertex2f(0.45f, -0.7f);
	glVertex2f(0.15f, -0.7f);
	glEnd();
	glBegin(GL_LINES);// drawing wave
	glColor3ub(255, 255, 255);
	glVertex2f(0.9f, -0.6f);
	glVertex2f(0.6f, -0.6f);
	glEnd();

	glBegin(GL_LINES);// drawing wave
	glColor3ub(255, 255, 255);
	glVertex2f(0.0f, -0.8f);
	glVertex2f(-0.3f, -0.8f);
	glEnd();
	glBegin(GL_LINES);// drawing wave
	glColor3ub(255, 255, 255);
	glVertex2f(-0.5f, -0.9f);
	glVertex2f(-0.8f, -0.9f);
	glEnd();
	glBegin(GL_LINES);// drawing wave
	glColor3ub(255, 255, 255);
	glVertex2f(-0.6f, -0.75f);
	glVertex2f(-0.88f, -0.75f);
	glEnd();


	glBegin(GL_QUADS); //drawing sand
	glColor3ub(255, 255, 179);
	glVertex2f(-1.0f, 0.35f);
	glVertex2f(-1.0f, 0.05f);
	glVertex2f(1.0f, 0.05f);
	glVertex2f(1.0f, 0.35f);
	glEnd();

	//drawing 1st building
	glBegin(GL_QUADS);
	glColor3ub(242, 242, 242);
	glVertex2f(-0.9f, 0.65f);
	glVertex2f(-0.9f, 0.35f);
	glVertex2f(-0.6f, 0.35f);
	glVertex2f(-0.6f, 0.65f);
	glEnd();
	glBegin(GL_QUADS);//drawing window
	glColor3ub(13, 13, 13);
	glVertex2f(-0.85f, 0.629f);
	glVertex2f(-0.85f, 0.56f);
	glVertex2f(-0.78f, 0.56f);
	glVertex2f(-0.78f, 0.629f);
	glEnd();
    glBegin(GL_QUADS);//drawing window
	glColor3ub(13, 13, 13);
	glVertex2f(-0.85f, 0.53f);
	glVertex2f(-0.85f, 0.46f);
	glVertex2f(-0.78f, 0.46f);
	glVertex2f(-0.78f, 0.53f);
	glEnd();
	glBegin(GL_QUADS);//drawing window
	glColor3ub(13, 13, 13);
	glVertex2f(-0.85f, 0.43f);
	glVertex2f(-0.85f, 0.36f);
	glVertex2f(-0.78f, 0.36f);
	glVertex2f(-0.78f, 0.43f);
	glEnd();
	glBegin(GL_QUADS);//drawing window
	glColor3ub(13, 13, 13);
	glVertex2f(-0.72f, 0.629f);
	glVertex2f(-0.72f, 0.56f);
	glVertex2f(-0.65f, 0.56f);
	glVertex2f(-0.65f, 0.629f);
	glEnd();
    glBegin(GL_QUADS);//drawing window
	glColor3ub(13, 13, 13);
	glVertex2f(-0.72f, 0.53f);
	glVertex2f(-0.72f, 0.46f);
	glVertex2f(-0.65f, 0.46f);
	glVertex2f(-0.65f, 0.53f);
	glEnd();
	glBegin(GL_QUADS);//drawing window
	glColor3ub(13, 13, 13);
	glVertex2f(-0.72f, 0.43f);
	glVertex2f(-0.72f, 0.36f);
	glVertex2f(-0.65f, 0.36f);
	glVertex2f(-0.65f, 0.43f);
	glEnd();
    //drawing 2nd building
	glBegin(GL_QUADS);
	glColor3ub(242, 242, 242);
	glVertex2f(-0.4f, 0.75f);
	glVertex2f(-0.4f, 0.35f);
	glVertex2f(-0.19f, 0.35f);
	glVertex2f(-0.19f, 0.75f);
	glEnd();
	glBegin(GL_QUADS); //window
	glColor3ub(13, 13, 13);
	glVertex2f(-0.37f, 0.75f);
	glVertex2f(-0.37f, 0.35f);
	glVertex2f(-0.33f, 0.35f);
	glVertex2f(-0.33f, 0.75f);
	glEnd();
	glBegin(GL_QUADS); //window
	glColor3ub(13, 13, 13);
	glVertex2f(-0.31f, 0.75f);
	glVertex2f(-0.31f, 0.35f);
	glVertex2f(-0.27f, 0.35f);
	glVertex2f(-0.27f, 0.75f);
	glEnd();
	glBegin(GL_QUADS); //window
	glColor3ub(13, 13, 13);
	glVertex2f(-0.25f, 0.75f);
	glVertex2f(-0.25f, 0.35f);
	glVertex2f(-0.22f, 0.35f);
	glVertex2f(-0.22f, 0.75f);
	glEnd();
	glBegin(GL_QUADS);
	glColor3ub(242, 242, 242);
	glVertex2f(-0.4f, 0.75f);
	glVertex2f(-0.4f, 0.73f);
	glVertex2f(-0.19f, 0.73f);
	glVertex2f(-0.19f, 0.75f);
	glEnd();
    //drawing 3rd building
	glBegin(GL_QUADS);
	glColor3ub(242, 242, 242);
	glVertex2f(0.0f, 0.58f);
	glVertex2f(0.0f, 0.35f);
	glVertex2f(0.7f, 0.35f);
	glVertex2f(0.7f, 0.58f);
	glEnd();
	glBegin(GL_QUADS);
	glColor3ub(0, 0, 0);
	glVertex2f(0.0f, 0.58f);
	glVertex2f(0.0f, 0.35f);
	glVertex2f(0.016f, 0.35f);
	glVertex2f(0.016f, 0.58f);
	glEnd();
	glBegin(GL_QUADS);
	glColor3ub(0, 0, 0);
	glVertex2f(0.7f, 0.58f);
	glVertex2f(0.7f, 0.35f);
	glVertex2f(0.716f, 0.35f);
	glVertex2f(0.716f, 0.58f);
	glEnd();
	glBegin(GL_QUADS);
	glColor3ub(0, 0, 0);
	glVertex2f(0.0f, 0.58f);
	glVertex2f(0.0f, 0.6f);
	glVertex2f(0.716f, 0.6f);
	glVertex2f(0.716f, 0.58f);
	glEnd();

	glBegin(GL_LINES);
	glColor3f(0.1f, 0.0f, 0.0f);
	glVertex2f(0.0f, 0.55f);
	glVertex2f(0.7f, 0.55f);
	glEnd();
	glBegin(GL_LINES);
	glColor3f(0.1f, 0.0f, 0.0f);
	glVertex2f(0.0f, 0.52f);
	glVertex2f(0.7f, 0.52f);
	glEnd();
	glBegin(GL_LINES);
	glColor3f(0.1f, 0.0f, 0.0f);
	glVertex2f(0.0f, 0.49f);
	glVertex2f(0.7f, 0.49f);
	glEnd();
	glBegin(GL_LINES);
	glColor3f(0.1f, 0.0f, 0.0f);
	glVertex2f(0.0f, 0.46f);
	glVertex2f(0.7f, 0.46f);
	glEnd();
	glBegin(GL_LINES);
	glColor3f(0.1f, 0.0f, 0.0f);
	glVertex2f(0.0f, 0.43f);
	glVertex2f(0.7f, 0.43f);
	glEnd();
	glBegin(GL_LINES);
	glColor3f(0.1f, 0.0f, 0.0f);
	glVertex2f(0.0f, 0.4f);
	glVertex2f(0.7f, 0.4f);
	glEnd();
	glBegin(GL_LINES);
	glColor3f(0.1f, 0.0f, 0.0f);
	glVertex2f(0.0f, 0.37f);
	glVertex2f(0.7f, 0.37f);
	glEnd();



	glBegin(GL_QUADS); //drawing the port's platform
	glColor3ub(138, 138, 92);
	glVertex2f(-0.3f, 0.25f);
	glVertex2f(-0.25f, 0.05f);
	glVertex2f(1.0f, 0.05f);
	glVertex2f(1.0f, 0.25f);
	glEnd();
	glBegin(GL_QUADS); //drawing the highway
	glColor3ub(115, 115, 115);
	glVertex2f(-1.f, 0.05f);
	glVertex2f(-1.0f, 0.25f);
	glVertex2f(-0.3f, 0.25f);
	glVertex2f(-0.25f, 0.05f);
	glEnd();
	glBegin(GL_QUADS); //drawing the highway
	glColor3ub(255, 255, 255);
	glVertex2f(-1.0f, 0.13f);
	glVertex2f(-1.0f, 0.139f);
	glVertex2f(-0.278f, 0.139f);
	glVertex2f(-0.278f, 0.13f);
	glEnd();
	glBegin(GL_QUADS); //drawing the highway
	glColor3ub(255, 255, 255);
	glVertex2f(-1.0f, 0.15f);
	glVertex2f(-1.0f, 0.159f);
	glVertex2f(-0.282f, 0.159f);
	glVertex2f(-0.282f, 0.15f);
	glEnd();

    glBegin(GL_QUADS); //drawing the tower platform
	glColor3ub(26, 26, 26);
	glVertex2f(-0.2f, 0.2f);
	glVertex2f(-0.2f, 0.17f);
	glVertex2f(-0.1f, 0.17f);
	glVertex2f(-0.1f, 0.2f);
	glEnd();
	glBegin(GL_QUADS); //drawing the tower
	glColor3ub(242, 242, 242);
	glVertex2f(-0.18f, 0.4f);
	glVertex2f(-0.18f, 0.2f);
	glVertex2f(-0.12f, 0.2f);
	glVertex2f(-0.12f, 0.4f);
	glEnd();

	glBegin(GL_QUADS); //drawing 1st career platform
	glColor3ub(204, 51, 0);
	glVertex2f(0.6f, 0.2f);
	glVertex2f(0.6f, 0.17f);
	glVertex2f(0.4f, 0.17f);
	glVertex2f(0.4f, 0.2f);
	glEnd();
	glBegin(GL_QUADS); //drawing the career
	glColor3ub(230, 92, 0);
	glVertex2f(0.48f, 0.5f);
	glVertex2f(0.48f, 0.2f);
	glVertex2f(0.52f, 0.2f);
	glVertex2f(0.52f, 0.5f);
	glEnd();
	glBegin(GL_QUADS); //drawing 2nd career platform
	glColor3ub(204, 51, 0);
	glVertex2f(0.3f, 0.2f);
	glVertex2f(0.3f, 0.17f);
	glVertex2f(0.5f, 0.17f);
	glVertex2f(0.5f, 0.2f);
	glEnd();
	/*glBegin(GL_QUADS); //ignoring this white container
	glColor3ub(255, 255, 255);
	glVertex2f(0.16f, 0.24f);
	glVertex2f(0.16f, 0.15f);
	glVertex2f(0.27f, 0.15f);
	glVertex2f(0.27f, 0.24f);
	glEnd();*/
	glBegin(GL_QUADS); //drawing the career
	glColor3ub(230, 92, 0);
	glVertex2f(0.38f, 0.5f);
	glVertex2f(0.38f, 0.2f);
	glVertex2f(0.42f, 0.2f);
	glVertex2f(0.42f, 0.5f);
	glEnd();
	glBegin(GL_QUADS); //drawing the 1st career horizontal
	glColor3ub(230, 57, 0);
	glVertex2f(0.38f, 0.48f);
	glVertex2f(0.38f, 0.46f);
	glVertex2f(0.1f, 0.46f);
	glVertex2f(0.1f, 0.48f);
	glEnd();
	glBegin(GL_QUADS); //drawing the 2nd career horizontal
	glColor3ub(230, 57, 0);
	glVertex2f(0.38f, 0.48f);
	glVertex2f(0.38f, 0.46f);
	glVertex2f(0.8f, 0.46f);
	glVertex2f(0.8f, 0.48f);
	glEnd();
	glBegin(GL_LINES); //drawing 1st ropes of career
	glColor3ub(77, 77, 77);
	glVertex2f(0.1f, 0.48f);
	glVertex2f(0.1f, 0.01f);
	glEnd();
	glBegin(GL_LINES); //drawing 2nd ropes of career
	glColor3ub(77, 77, 77);
	glVertex2f(0.8f, 0.48f);
	glVertex2f(0.8f, 0.32f);
	glEnd();
	glBegin(GL_QUADS); //drawing the yellow container
	glColor3ub(255, 255, 0);
	glVertex2f(0.85f, 0.4f);
	glVertex2f(0.85f, 0.32f);
	glVertex2f(0.75f, 0.32f);
	glVertex2f(0.75f, 0.4f);
	glEnd();





	//drawing the 2nd ship
	glBegin(GL_QUADS); //drawing the ship
	glColor3ub(179, 45, 0);
	glVertex2f(-0.8f, -0.5f);
	glVertex2f(-0.78f, -0.64f);
	glVertex2f(0.05f, -0.64f);
	glVertex2f(0.1f, -0.5f);
	glEnd();
	glBegin(GL_QUADS); //drawing upper part of the ship
	glColor3ub(255, 255, 255);
	glVertex2f(-0.76f, -0.37f);
	glVertex2f(-0.76f, -0.5f);
	glVertex2f(-0.5f, -0.5f);
	glVertex2f(-0.5f, -0.37f);
	glEnd();
	glBegin(GL_QUADS); //drawing border
	glColor3ub(26, 26, 26);
	glVertex2f(-0.8f, -0.47f);
	glVertex2f(-0.78f, -0.54f);
	glVertex2f(0.05f, -0.54f);
	glVertex2f(0.1f, -0.47f);
	glEnd();
	glBegin(GL_QUADS); //drawing BORDER
	glColor3ub(26, 26, 26);
	glVertex2f(-0.8f, -0.47f);
	glVertex2f(-0.8f, -0.5f);
	glVertex2f(0.1f, -0.5f);
	glVertex2f(0.1f, -0.47f);
	glEnd();
	glBegin(GL_QUADS); //drawing yellow container
	glColor3ub(255, 255, 0);
	glVertex2f(-0.48f, -0.47f);
	glVertex2f(-0.48f, -0.34f);
	glVertex2f(-0.25f, -0.34f);
	glVertex2f(-0.25f, -0.47f);
	glEnd();
	glBegin(GL_QUADS); //drawing blue container
	glColor3ub(255, 255, 0);
	glVertex2f(-0.48f, -0.47f);
	glVertex2f(-0.48f, -0.34f);
	glVertex2f(-0.25f, -0.34f);
	glVertex2f(-0.25f, -0.47f);
	glEnd();
	glBegin(GL_QUADS); //drawing green container
	glColor3ub(0, 0, 153);
	glVertex2f(-0.23f, -0.47f);
	glVertex2f(-0.23f, -0.35f);
	glVertex2f(0.03f, -0.35f);
	glVertex2f(0.03f, -0.47f);
	glEnd();

	//1st truck
	glBegin(GL_QUADS);
	glColor3ub(38, 38, 38);
	glVertex2f(0.63f, 0.2f);
	glVertex2f(0.63f, 0.16f);
	glVertex2f(0.97f, 0.16f);
	glVertex2f(0.97f, 0.2f);
	glEnd();
	glBegin(GL_QUADS);
	glColor3ub(230, 46, 0);
	glVertex2f(0.9f, 0.25f);
	glVertex2f(0.9f, 0.2f);
	glVertex2f(0.97f, 0.2f);
	glVertex2f(0.97f, 0.25f);
	glEnd();
	glBegin(GL_QUADS);
	glColor3ub(255, 255, 255);
	glVertex2f(0.925f, 0.235f);
	glVertex2f(0.925f, 0.215f);
	glVertex2f(0.95f, 0.215f);
	glVertex2f(0.95f, 0.235f);
	glEnd();
	glBegin(GL_QUADS);
	glColor3ub(0, 102, 255);
	glVertex2f(0.63f, 0.3f);
	glVertex2f(0.63f, 0.2f);
	glVertex2f(0.9f, 0.2f);
	glVertex2f(0.9f, 0.3f);
	glEnd();
	//flag
	glBegin(GL_LINES); //stand
	glColor3f(0.1f, 0.0f, 0.0f);
	glVertex2f(0.08f, -0.5f);
	glVertex2f(0.08f, -0.25f);
	glEnd();
	glBegin(GL_QUADS); //rectangle
	glColor3ub(0, 153, 0);
	glVertex2f(0.073f, -0.21f);
	glVertex2f(0.073f, -0.32f);
	glVertex2f(0.26f, -0.32f);
	glVertex2f(0.26f, -0.21f);
	glEnd();


	GLfloat x=.3f; GLfloat y=.2f; GLfloat radius =.2f;
	int i;
	int lineAmount = 150;
	GLfloat twicePi = 2.0f * PI;


	x=-0.15f; y=0.42f;  radius =.07f; //drawing the tower
	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(51, 51, 51);
		for(i = 0; i <= lineAmount;i++) {
			glVertex2f(
			    x + (radius * cos(i *  twicePi / lineAmount)),
			    y + (radius* sin(i * twicePi / lineAmount))
			);
		}
	glEnd();

	x=0.9f; y=0.15f;  radius =.03f; //drawing tires
	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(0, 0, 0);
		for(i = 0; i <= lineAmount;i++) {
			glVertex2f(
			    x + (radius * cos(i *  twicePi / lineAmount)),
			    y + (radius* sin(i * twicePi / lineAmount))
			);
		}
	glEnd();
	x=0.7f; y=0.15f;  radius =.03f; //drawing tires
	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(0, 0, 0);
		for(i = 0; i <= lineAmount;i++) {
			glVertex2f(
			    x + (radius * cos(i *  twicePi / lineAmount)),
			    y + (radius* sin(i * twicePi / lineAmount))
			);
		}
	glEnd();
	x=0.7f; y=0.15f;  radius =.009f; //drawing tires
	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(255, 255, 255);
		for(i = 0; i <= lineAmount;i++) {
			glVertex2f(
			    x + (radius * cos(i *  twicePi / lineAmount)),
			    y + (radius* sin(i * twicePi / lineAmount))
			);
		}
	glEnd();
	x=0.9f; y=0.15f;  radius =.009f; //drawing tires
	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(255, 255, 255);
		for(i = 0; i <= lineAmount;i++) {
			glVertex2f(
			    x + (radius * cos(i *  twicePi / lineAmount)),
			    y + (radius* sin(i * twicePi / lineAmount))
			);
		}
	glEnd();

	x=0.17f; y=-0.26f;  radius =.034f; //drawing tires
	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(179, 0, 0);
		for(i = 0; i <= lineAmount;i++) {
			glVertex2f(
			    x + (radius * cos(i *  twicePi / lineAmount)),
			    y + (radius* sin(i * twicePi / lineAmount))
			);
		}
	glEnd();



glPushMatrix();
glTranslatef(position,0.0f, 0.0f);
    glBegin(GL_QUADS); //2nd truck
	glColor3ub(38, 38, 38);
	glVertex2f(-0.5f, 0.2f);
	glVertex2f(-0.5f, 0.16f);
	glVertex2f(-0.9f, 0.16f);
	glVertex2f(-0.9f, 0.2f);
	glEnd();
	glBegin(GL_QUADS);
	glColor3ub(179, 71, 0);
	glVertex2f(-0.63f, 0.25f);
	glVertex2f(-0.63f, 0.2f);
	glVertex2f(-0.5f, 0.2f);
	glVertex2f(-0.5f, 0.25f);
	glEnd();
	glBegin(GL_QUADS);
	glColor3ub(0, 128, 0);
	glVertex2f(-0.63f, 0.3f);
	glVertex2f(-0.63f, 0.2f);
	glVertex2f(-0.9f, 0.2f);
	glVertex2f(-0.9f, 0.3f);
	glEnd();
	glBegin(GL_QUADS);
	glColor3ub(255, 255, 255);
	glVertex2f(-0.54f, 0.21f);
	glVertex2f(-0.54f, 0.23f);
	glVertex2f(-0.52f, 0.23f);
	glVertex2f(-0.52f, 0.21f);
	glEnd();
	glBegin(GL_QUADS);
	glColor3ub(255, 255, 255);
	glVertex2f(-0.58f, 0.21f);
	glVertex2f(-0.58f, 0.23f);
	glVertex2f(-0.56f, 0.23f);
	glVertex2f(-0.56f, 0.21f);
	glEnd();


	 x=-0.58f;  y=0.15f; radius =.03f; //drawing tires
	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(0, 0, 0);
		for(i = 0; i <= lineAmount;i++) {
			glVertex2f(
			    x + (radius * cos(i *  twicePi / lineAmount)),
			    y + (radius* sin(i * twicePi / lineAmount))
			);
		}
	glEnd();
		x=-0.8f; y=0.15f;  radius =.03f; //drawing tires
	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(0, 0, 0);
		for(i = 0; i <= lineAmount;i++) {
			glVertex2f(
			    x + (radius * cos(i *  twicePi / lineAmount)),
			    y + (radius* sin(i * twicePi / lineAmount))
			);
		}
	glEnd();
		x=-0.8f; y=0.15f;  radius =.01f; //drawing tires
	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(255, 255, 255);
		for(i = 0; i <= lineAmount;i++) {
			glVertex2f(
			    x + (radius * cos(i *  twicePi / lineAmount)),
			    y + (radius* sin(i * twicePi / lineAmount))
			);
		}
	glEnd();
	x=-0.58f; y=0.15f;  radius =.01f; //drawing tires
	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(255, 255, 255);
		for(i = 0; i <= lineAmount;i++) {
			glVertex2f(
			    x + (radius * cos(i *  twicePi / lineAmount)),
			    y + (radius* sin(i * twicePi / lineAmount))
			);
		}
	glEnd();

glPopMatrix();

    x=-0.8f; y=0.85f;  radius =.07f; //drawing the sun
	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(255, 204, 0);
		for(i = 0; i <= lineAmount;i++) {
			glVertex2f(
			    x + (radius * cos(i *  twicePi / lineAmount)),
			    y + (radius* sin(i * twicePi / lineAmount))
			);
		}
	glEnd();
glBegin(GL_QUADS); //drawing blue container
	glColor3ub(0, 0, 179);
	glVertex2f(0.02f, 0.12f);
	glVertex2f(0.02f, 0.01f);
	glVertex2f(0.17f, 0.01f);
	glVertex2f(0.17f, 0.12f);
	glEnd();

glPushMatrix();
glTranslatef(position1,0.0f, 0.0f);
	glBegin(GL_QUADS); //drawing the 1st ship
	glColor3ub(77, 77, 77);
	glVertex2f(-0.25f, -0.1f);
	glVertex2f(-0.22f, -0.16f);
	glVertex2f(0.32f, -0.16f);
	glVertex2f(0.33f, -0.1f);
	glEnd();
	glBegin(GL_QUADS); //drawing the 1st ship
	glColor3ub(77, 77, 77);
	glVertex2f(0.32f, -0.15f);
	glVertex2f(0.18f, -0.15f);
	glVertex2f(0.18f, -0.04f);
	glVertex2f(0.32f, -0.04f);
	glEnd();
	glBegin(GL_QUADS); //drawing border of the 1st ship
	glColor3ub(255, 255, 204);
	glVertex2f(-0.25f, -0.09f);
	glVertex2f(-0.25f, -0.1f);
	glVertex2f(0.33f, -0.1f);
	glVertex2f(0.33f, -0.09f);
	glBegin(GL_QUADS); //drawing shadow of the 1st ship
	glColor3ub(176, 176, 130);
	glVertex2f(-0.25f, -0.18f);
	glVertex2f(-0.22f, -0.16f);
	glVertex2f(0.32f, -0.16f);
	glVertex2f(0.33f, -0.18f);
	glEnd();

	//drawing container

	glBegin(GL_QUADS); //drawing yellow container
	glColor3ub(2255, 173, 51);
	glVertex2f(-0.22f, -0.01f);
	glVertex2f(-0.22f, -0.09f);
	glVertex2f(-0.09f, -0.09f);
	glVertex2f(-0.09f, -0.01f);
	glEnd();
	glBegin(GL_QUADS); //drawing red container
	glColor3ub(255, 51, 51);
	glVertex2f(-0.07f, -0.09f);
	glVertex2f(-0.07f, -0.01f);
	glVertex2f(0.01f, -0.01f);
	glVertex2f(0.01f, -0.09f);
	glEnd();
glPopMatrix();
glFlush();

}


int main(int argc, char** argv) {
	glutInit(&argc, argv);                 // Initialize GLUT
	glutInitWindowSize(320, 320);
   glutInitWindowPosition(50, 50);
   glutCreateWindow("Translation Animation");   // Set the window's initial width & height
	glutDisplayFunc(display); // Register display callback handler for window re-paint
	glutTimerFunc(100, update, 0);
    glutTimerFunc(100, update1, 0);

	glutMainLoop();           // Enter the event-processing loop
	return 0;
}

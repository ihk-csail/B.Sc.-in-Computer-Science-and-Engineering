<html>
<body>

<hr>
<span style = "display:inline-block; width:100%; height:10%; text-align:center;">
<?php
echo "<p>Copyright &copy; 2021</p>";
echo "<p> POWERED BY WEBTECH G4</P>";
?>
</span> 


</body>
</html>
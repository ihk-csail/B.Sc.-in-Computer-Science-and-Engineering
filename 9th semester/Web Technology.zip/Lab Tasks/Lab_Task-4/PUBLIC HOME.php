<html>
<body>

<?php include 'header.php';?>


<h1 align="center">WELCOME TO CLOUD SUPER SHOP</h1></p>


<?php include 'footer.php';?>

</body>
</html>